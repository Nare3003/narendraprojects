# Inkwell — Full-Stack Blog Platform

A full-stack blogging platform where users can register, write posts, and interact through comments. Built with React, Node.js, Express, and SQLite.

![Inkwell Blog Platform](https://img.shields.io/badge/status-ready-brightgreen) ![License](https://img.shields.io/badge/license-MIT-blue)

## Features

- **Authentication** — Register, log in, and log out with JWT-based sessions
- **Blog posts** — Create, edit, delete, and browse posts with category filtering
- **Comments** — Threaded comment sections on every post
- **Likes** — Like/unlike posts; counts tracked per user
- **Search** — Live search across post titles and excerpts
- **Responsive UI** — Works on desktop and mobile

## Tech Stack

| Layer     | Technology                        |
|-----------|-----------------------------------|
| Frontend  | React 18, React Router, Axios     |
| Backend   | Node.js, Express                  |
| Database  | SQLite (via `better-sqlite3`)     |
| Auth      | JSON Web Tokens (JWT), bcrypt     |
| Styling   | Plain CSS (no framework)          |

## Project Structure

```
inkwell/
├── backend/
│   ├── config/
│   │   └── db.js            # SQLite connection & schema setup
│   ├── middleware/
│   │   └── auth.js          # JWT verification middleware
│   ├── models/
│   │   ├── user.js
│   │   ├── post.js
│   │   └── comment.js
│   ├── routes/
│   │   ├── auth.js          # POST /api/auth/register, /login
│   │   ├── posts.js         # CRUD /api/posts
│   │   └── comments.js      # CRUD /api/comments
│   ├── server.js
│   └── package.json
│
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── Navbar.jsx
│   │   │   ├── PostCard.jsx
│   │   │   └── CommentSection.jsx
│   │   ├── context/
│   │   │   └── AuthContext.jsx
│   │   ├── pages/
│   │   │   ├── Home.jsx
│   │   │   ├── PostView.jsx
│   │   │   ├── MyPosts.jsx
│   │   │   ├── Login.jsx
│   │   │   └── Register.jsx
│   │   ├── hooks/
│   │   │   └── useAuth.js
│   │   ├── App.jsx
│   │   ├── main.jsx
│   │   └── index.css
│   ├── index.html
│   └── package.json
│
├── .gitignore
└── README.md
```

## Getting Started

### Prerequisites

- Node.js 18+
- npm 9+

### 1. Clone the repository

```bash
git clone https://github.com/your-username/inkwell.git
cd inkwell
```

### 2. Set up the backend

```bash
cd backend
npm install
```

Create a `.env` file in the `backend/` folder:

```env
PORT=5000
JWT_SECRET=your_super_secret_key_here
```

Start the backend server:

```bash
npm run dev
```

The API will be available at `http://localhost:5000`.

### 3. Set up the frontend

```bash
cd ../frontend
npm install
npm run dev
```

The app will be available at `http://localhost:5173`.

## API Reference

### Auth

| Method | Endpoint              | Description         | Auth required |
|--------|-----------------------|---------------------|---------------|
| POST   | `/api/auth/register`  | Create account      | No            |
| POST   | `/api/auth/login`     | Log in, get JWT     | No            |

### Posts

| Method | Endpoint          | Description         | Auth required |
|--------|-------------------|---------------------|---------------|
| GET    | `/api/posts`      | List all posts      | No            |
| GET    | `/api/posts/:id`  | Get one post        | No            |
| POST   | `/api/posts`      | Create a post       | Yes           |
| PUT    | `/api/posts/:id`  | Edit a post         | Yes (owner)   |
| DELETE | `/api/posts/:id`  | Delete a post       | Yes (owner)   |
| POST   | `/api/posts/:id/like` | Toggle like     | Yes           |

### Comments

| Method | Endpoint              | Description         | Auth required |
|--------|-----------------------|---------------------|---------------|
| GET    | `/api/comments/:postId` | Get comments      | No            |
| POST   | `/api/comments`       | Add a comment       | Yes           |
| DELETE | `/api/comments/:id`   | Delete a comment    | Yes (owner)   |

## Environment Variables

| Variable     | Location  | Description                  |
|--------------|-----------|------------------------------|
| `PORT`       | backend   | Port for the Express server  |
| `JWT_SECRET` | backend   | Secret for signing JWTs      |

## Contributing

1. Fork the repo
2. Create a feature branch: `git checkout -b feature/your-feature`
3. Commit your changes: `git commit -m 'Add your feature'`
4. Push and open a pull request

## License

MIT — see [LICENSE](LICENSE) for details.
