const express = require('express');
const db = require('../config/db');
const authenticate = require('../middleware/auth');

const router = express.Router();

// GET /api/comments/:postId
router.get('/:postId', (req, res) => {
  const comments = db.prepare(`
    SELECT c.*, u.name AS author_name
    FROM comments c JOIN users u ON u.id = c.author_id
    WHERE c.post_id = ?
    ORDER BY c.created_at ASC
  `).all(req.params.postId);

  res.json(comments);
});

// POST /api/comments
router.post('/', authenticate, (req, res) => {
  const { post_id, body } = req.body;
  if (!post_id || !body)
    return res.status(400).json({ error: 'post_id and body are required.' });

  const result = db.prepare(
    'INSERT INTO comments (post_id, author_id, body) VALUES (?, ?, ?)'
  ).run(post_id, req.user.id, body);

  res.status(201).json({ id: result.lastInsertRowid });
});

// DELETE /api/comments/:id
router.delete('/:id', authenticate, (req, res) => {
  const comment = db.prepare('SELECT * FROM comments WHERE id = ?').get(req.params.id);
  if (!comment) return res.status(404).json({ error: 'Comment not found.' });
  if (comment.author_id !== req.user.id)
    return res.status(403).json({ error: 'Not authorized.' });

  db.prepare('DELETE FROM comments WHERE id = ?').run(comment.id);
  res.json({ message: 'Comment deleted.' });
});

module.exports = router;
