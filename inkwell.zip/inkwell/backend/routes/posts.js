const express = require('express');
const db = require('../config/db');
const authenticate = require('../middleware/auth');

const router = express.Router();

// GET /api/posts
router.get('/', (req, res) => {
  const { search, category } = req.query;
  let query = `
    SELECT p.*, u.name AS author_name, u.bio AS author_bio,
      (SELECT COUNT(*) FROM likes WHERE post_id = p.id) AS like_count,
      (SELECT COUNT(*) FROM comments WHERE post_id = p.id) AS comment_count
    FROM posts p JOIN users u ON u.id = p.author_id
    WHERE 1=1
  `;
  const params = [];

  if (search) {
    query += ` AND (p.title LIKE ? OR p.excerpt LIKE ?)`;
    params.push(`%${search}%`, `%${search}%`);
  }
  if (category && category !== 'all') {
    query += ` AND LOWER(p.category) = LOWER(?)`;
    params.push(category);
  }
  query += ` ORDER BY p.created_at DESC`;

  res.json(db.prepare(query).all(...params));
});

// GET /api/posts/:id
router.get('/:id', (req, res) => {
  const post = db.prepare(`
    SELECT p.*, u.name AS author_name, u.bio AS author_bio,
      (SELECT COUNT(*) FROM likes WHERE post_id = p.id) AS like_count,
      (SELECT COUNT(*) FROM comments WHERE post_id = p.id) AS comment_count
    FROM posts p JOIN users u ON u.id = p.author_id
    WHERE p.id = ?
  `).get(req.params.id);

  if (!post) return res.status(404).json({ error: 'Post not found.' });
  res.json(post);
});

// POST /api/posts
router.post('/', authenticate, (req, res) => {
  const { title, excerpt, body, category = 'General' } = req.body;
  if (!title || !excerpt || !body)
    return res.status(400).json({ error: 'Title, excerpt, and body are required.' });

  const result = db.prepare(
    'INSERT INTO posts (author_id, title, excerpt, body, category) VALUES (?, ?, ?, ?, ?)'
  ).run(req.user.id, title, excerpt, body, category);

  res.status(201).json({ id: result.lastInsertRowid });
});

// PUT /api/posts/:id
router.put('/:id', authenticate, (req, res) => {
  const post = db.prepare('SELECT * FROM posts WHERE id = ?').get(req.params.id);
  if (!post) return res.status(404).json({ error: 'Post not found.' });
  if (post.author_id !== req.user.id)
    return res.status(403).json({ error: 'Not authorized.' });

  const { title, excerpt, body, category } = req.body;
  db.prepare(`
    UPDATE posts SET title = ?, excerpt = ?, body = ?, category = ?, updated_at = datetime('now')
    WHERE id = ?
  `).run(title ?? post.title, excerpt ?? post.excerpt, body ?? post.body, category ?? post.category, post.id);

  res.json({ message: 'Post updated.' });
});

// DELETE /api/posts/:id
router.delete('/:id', authenticate, (req, res) => {
  const post = db.prepare('SELECT * FROM posts WHERE id = ?').get(req.params.id);
  if (!post) return res.status(404).json({ error: 'Post not found.' });
  if (post.author_id !== req.user.id)
    return res.status(403).json({ error: 'Not authorized.' });

  db.prepare('DELETE FROM posts WHERE id = ?').run(post.id);
  res.json({ message: 'Post deleted.' });
});

// POST /api/posts/:id/like  (toggle)
router.post('/:id/like', authenticate, (req, res) => {
  const existing = db.prepare(
    'SELECT * FROM likes WHERE user_id = ? AND post_id = ?'
  ).get(req.user.id, req.params.id);

  if (existing) {
    db.prepare('DELETE FROM likes WHERE user_id = ? AND post_id = ?').run(req.user.id, req.params.id);
    res.json({ liked: false });
  } else {
    db.prepare('INSERT INTO likes (user_id, post_id) VALUES (?, ?)').run(req.user.id, req.params.id);
    res.json({ liked: true });
  }
});

// GET /api/posts/:id/likes (check if current user liked)
router.get('/:id/likes', authenticate, (req, res) => {
  const liked = !!db.prepare(
    'SELECT 1 FROM likes WHERE user_id = ? AND post_id = ?'
  ).get(req.user.id, req.params.id);
  res.json({ liked });
});

module.exports = router;
