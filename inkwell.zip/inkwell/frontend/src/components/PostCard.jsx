import { useNavigate } from 'react-router-dom';

function fmt(d) {
  return new Date(d).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

export default function PostCard({ post }) {
  const navigate = useNavigate();

  return (
    <div className="post-card" onClick={() => navigate(`/posts/${post.id}`)}>
      <div className="post-meta">
        <span className="tag">{post.category}</span>
        <span className="post-date">{fmt(post.created_at)}</span>
      </div>
      <h2 className="post-title">{post.title}</h2>
      <p className="post-excerpt">{post.excerpt}</p>
      <div className="post-footer">
        <span className="author-name">{post.author_name}</span>
        <span className="dot" />
        <span>💬 {post.comment_count}</span>
        <span>♥ {post.like_count}</span>
      </div>
    </div>
  );
}
