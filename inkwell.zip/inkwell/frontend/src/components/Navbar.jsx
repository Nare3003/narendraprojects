import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

function initials(name) {
  return name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();
}

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  function handleLogout() {
    logout();
    navigate('/');
  }

  return (
    <nav className="navbar">
      <Link to="/" className="nav-brand">🪶 Inkwell</Link>
      <div className="nav-spacer" />
      {user ? (
        <div className="nav-user">
          <span className="nav-username">{user.name}</span>
          <div className="avatar">{initials(user.name)}</div>
          <Link to="/my-posts" className="btn btn-sm">My posts</Link>
          <Link to="/new-post" className="btn btn-sm btn-primary">Write</Link>
          <button className="btn btn-sm" onClick={handleLogout}>Log out</button>
        </div>
      ) : (
        <div className="nav-user">
          <Link to="/login" className="btn btn-sm">Log in</Link>
          <Link to="/register" className="btn btn-sm btn-primary">Sign up</Link>
        </div>
      )}
    </nav>
  );
}
