import { useState, useEffect } from 'react';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';

function fmt(d) {
  return new Date(d).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

export default function CommentSection({ postId }) {
  const { user } = useAuth();
  const [comments, setComments] = useState([]);
  const [body, setBody] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    axios.get(`/api/comments/${postId}`).then(r => setComments(r.data));
  }, [postId]);

  async function submit() {
    if (!body.trim()) return;
    try {
      await axios.post('/api/comments', { post_id: postId, body });
      setBody('');
      const r = await axios.get(`/api/comments/${postId}`);
      setComments(r.data);
    } catch (e) {
      setError(e.response?.data?.error || 'Failed to post comment.');
    }
  }

  async function remove(id) {
    await axios.delete(`/api/comments/${id}`);
    setComments(c => c.filter(x => x.id !== id));
  }

  return (
    <div className="comments-section">
      <h3 className="comments-title">{comments.length} comment{comments.length !== 1 ? 's' : ''}</h3>

      <div className="comments-list">
        {comments.length === 0 && <p className="empty-text">No comments yet. Be the first.</p>}
        {comments.map(c => (
          <div key={c.id} className="comment">
            <div className="comment-header">
              <strong>{c.author_name}</strong>
              <span className="comment-time">{fmt(c.created_at)}</span>
              {user?.id === c.author_id && (
                <button className="btn btn-sm btn-danger" onClick={() => remove(c.id)}>Delete</button>
              )}
            </div>
            <p className="comment-body">{c.body}</p>
          </div>
        ))}
      </div>

      {user ? (
        <div className="comment-form">
          <textarea
            value={body}
            onChange={e => setBody(e.target.value)}
            placeholder="Share your thoughts…"
            rows={3}
          />
          {error && <p className="error">{error}</p>}
          <button className="btn btn-primary" onClick={submit}>Post comment</button>
        </div>
      ) : (
        <p className="login-prompt">
          <a href="/login">Log in</a> to leave a comment.
        </p>
      )}
    </div>
  );
}
