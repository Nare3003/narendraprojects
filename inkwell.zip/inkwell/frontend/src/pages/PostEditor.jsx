import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import axios from 'axios';

const CATEGORIES = ['Technology', 'Engineering', 'Productivity', 'Design', 'Science', 'Culture', 'Other'];

export default function PostEditor() {
  const { id } = useParams();
  const navigate = useNavigate();
  const editing = !!id;

  const [form, setForm] = useState({ title: '', excerpt: '', body: '', category: 'Technology' });
  const [error, setError] = useState('');

  useEffect(() => {
    if (editing) {
      axios.get(`/api/posts/${id}`).then(r => {
        const { title, excerpt, body, category } = r.data;
        setForm({ title, excerpt, body, category });
      });
    }
  }, [id]);

  function set(field) {
    return e => setForm(f => ({ ...f, [field]: e.target.value }));
  }

  async function submit() {
    setError('');
    if (!form.title || !form.excerpt || !form.body) {
      setError('Title, excerpt, and body are required.');
      return;
    }
    try {
      if (editing) {
        await axios.put(`/api/posts/${id}`, form);
        navigate(`/posts/${id}`);
      } else {
        const r = await axios.post('/api/posts', form);
        navigate(`/posts/${r.data.id}`);
      }
    } catch (e) {
      setError(e.response?.data?.error || 'Something went wrong.');
    }
  }

  return (
    <main className="main-content">
      <h1 className="page-title">{editing ? 'Edit post' : 'New post'}</h1>
      <div className="card">
        <div className="form-group">
          <label className="form-label">Title</label>
          <input type="text" value={form.title} onChange={set('title')} placeholder="Give it a strong headline" />
        </div>
        <div className="form-group">
          <label className="form-label">Category</label>
          <select value={form.category} onChange={set('category')}>
            {CATEGORIES.map(c => <option key={c}>{c}</option>)}
          </select>
        </div>
        <div className="form-group">
          <label className="form-label">Excerpt</label>
          <input type="text" value={form.excerpt} onChange={set('excerpt')} placeholder="A one-line summary" />
        </div>
        <div className="form-group">
          <label className="form-label">Body</label>
          <textarea value={form.body} onChange={set('body')} rows={12} placeholder="Write your post here…" />
        </div>
        {error && <p className="error">{error}</p>}
        <div style={{ display: 'flex', gap: '8px' }}>
          <button className="btn btn-primary" onClick={submit}>{editing ? 'Save changes' : 'Publish'}</button>
          <button className="btn" onClick={() => navigate(-1)}>Cancel</button>
        </div>
      </div>
    </main>
  );
}
