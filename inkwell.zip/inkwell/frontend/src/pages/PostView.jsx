import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import CommentSection from '../components/CommentSection';

function fmt(d) {
  return new Date(d).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

export default function PostView() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [post, setPost] = useState(null);
  const [liked, setLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(0);

  useEffect(() => {
    axios.get(`/api/posts/${id}`).then(r => {
      setPost(r.data);
      setLikeCount(r.data.like_count);
    });
    if (user) {
      axios.get(`/api/posts/${id}/likes`).then(r => setLiked(r.data.liked));
    }
  }, [id, user]);

  async function toggleLike() {
    if (!user) { navigate('/login'); return; }
    const r = await axios.post(`/api/posts/${id}/like`);
    setLiked(r.data.liked);
    setLikeCount(c => r.data.liked ? c + 1 : c - 1);
  }

  async function deletePost() {
    if (!confirm('Delete this post?')) return;
    await axios.delete(`/api/posts/${id}`);
    navigate('/');
  }

  if (!post) return <main className="main-content"><p className="loading">Loading…</p></main>;

  const isOwner = user?.id === post.author_id;

  return (
    <main className="main-content">
      <button className="back-btn" onClick={() => navigate('/')}>← All posts</button>

      <div className="card post-full">
        <div className="post-meta">
          <span className="tag">{post.category}</span>
          <span className="post-date">{fmt(post.created_at)}</span>
        </div>
        <h1 className="post-full-title">{post.title}</h1>
        <p className="post-author">{post.author_name}</p>
        <div className="post-full-body">{post.body}</div>

        <div className="post-actions">
          <button className={`like-btn ${liked ? 'liked' : ''}`} onClick={toggleLike}>
            {liked ? '♥' : '♡'} {likeCount} {likeCount === 1 ? 'like' : 'likes'}
          </button>
          {isOwner && (
            <div className="owner-actions">
              <button className="btn btn-sm" onClick={() => navigate(`/edit-post/${post.id}`)}>Edit</button>
              <button className="btn btn-sm btn-danger" onClick={deletePost}>Delete</button>
            </div>
          )}
        </div>
      </div>

      <CommentSection postId={post.id} />
    </main>
  );
}
