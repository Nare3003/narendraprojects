import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';

function fmt(d) {
  return new Date(d).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

export default function MyPosts() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    axios.get('/api/posts').then(r => {
      setPosts(r.data.filter(p => p.author_id === user?.id));
    });
  }, [user]);

  async function remove(id) {
    if (!confirm('Delete this post?')) return;
    await axios.delete(`/api/posts/${id}`);
    setPosts(p => p.filter(x => x.id !== id));
  }

  return (
    <main className="main-content">
      <div className="page-header">
        <h1 className="page-title">My posts</h1>
        <Link to="/new-post" className="btn btn-primary">Write new</Link>
      </div>

      {posts.length === 0 ? (
        <p className="empty-text">You haven't written anything yet.</p>
      ) : (
        <div className="post-grid">
          {posts.map(p => (
            <div key={p.id} className="post-card" onClick={() => navigate(`/posts/${p.id}`)}>
              <div className="post-meta">
                <span className="tag">{p.category}</span>
                <span className="post-date">{fmt(p.created_at)}</span>
              </div>
              <h2 className="post-title">{p.title}</h2>
              <div className="post-footer">
                <span>♥ {p.like_count}</span>
                <span>💬 {p.comment_count}</span>
                <div className="owner-actions" onClick={e => e.stopPropagation()}>
                  <button className="btn btn-sm" onClick={() => navigate(`/edit-post/${p.id}`)}>Edit</button>
                  <button className="btn btn-sm btn-danger" onClick={() => remove(p.id)}>Delete</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </main>
  );
}
