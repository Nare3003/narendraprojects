import { useState, useEffect } from 'react';
import axios from 'axios';
import PostCard from '../components/PostCard';

const CATEGORIES = ['all', 'Technology', 'Engineering', 'Productivity', 'Design', 'Science', 'Culture', 'Other'];

export default function Home() {
  const [posts, setPosts] = useState([]);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    const params = {};
    if (search) params.search = search;
    if (category !== 'all') params.category = category;
    axios.get('/api/posts', { params })
      .then(r => setPosts(r.data))
      .finally(() => setLoading(false));
  }, [search, category]);

  return (
    <main className="main-content">
      <div className="action-bar">
        <input
          type="text"
          className="search-input"
          placeholder="Search posts…"
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
      </div>

      <div className="tabs">
        {CATEGORIES.map(c => (
          <button
            key={c}
            className={`tab ${category === c ? 'active' : ''}`}
            onClick={() => setCategory(c)}
          >
            {c.charAt(0).toUpperCase() + c.slice(1)}
          </button>
        ))}
      </div>

      {loading ? (
        <p className="loading">Loading…</p>
      ) : posts.length === 0 ? (
        <p className="empty-text">No posts found.</p>
      ) : (
        <div className="post-grid">
          {posts.map(p => <PostCard key={p.id} post={p} />)}
        </div>
      )}
    </main>
  );
}
