import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';

export default function Register() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', password: '', bio: '' });
  const [error, setError] = useState('');

  function set(f) { return e => setForm(x => ({ ...x, [f]: e.target.value })); }

  async function submit(e) {
    e.preventDefault();
    setError('');
    try {
      const r = await axios.post('/api/auth/register', form);
      login(r.data.token, r.data.user);
      navigate('/');
    } catch (err) {
      setError(err.response?.data?.error || 'Registration failed.');
    }
  }

  return (
    <div className="auth-wrap">
      <div className="auth-card">
        <h1 className="auth-title">Create account</h1>
        <p className="auth-sub">Join Inkwell and start writing.</p>
        <form onSubmit={submit}>
          <div className="form-group">
            <label className="form-label">Full name</label>
            <input type="text" value={form.name} onChange={set('name')} placeholder="Your name" required />
          </div>
          <div className="form-group">
            <label className="form-label">Email</label>
            <input type="email" value={form.email} onChange={set('email')} placeholder="you@example.com" required />
          </div>
          <div className="form-group">
            <label className="form-label">Password</label>
            <input type="password" value={form.password} onChange={set('password')} placeholder="At least 6 characters" required />
          </div>
          <div className="form-group">
            <label className="form-label">Bio <span style={{ fontWeight: 400, color: 'var(--color-text-tertiary)' }}>(optional)</span></label>
            <input type="text" value={form.bio} onChange={set('bio')} placeholder="A short line about yourself" />
          </div>
          {error && <p className="error">{error}</p>}
          <button type="submit" className="btn btn-primary" style={{ width: '100%' }}>Create account</button>
        </form>
        <p className="auth-switch">Already have an account? <Link to="/login">Log in</Link></p>
      </div>
    </div>
  );
}
