-- ─────────────────────────────────────────────────────────
--  Portfolio Database Schema
--  Run this once to set up your PostgreSQL database
--  Usage: psql -U your_user -d your_db -f config/schema.sql
-- ─────────────────────────────────────────────────────────

-- Messages (contact form submissions)
CREATE TABLE IF NOT EXISTS messages (
  id          SERIAL PRIMARY KEY,
  fname       VARCHAR(80)  NOT NULL,
  lname       VARCHAR(80),
  email       VARCHAR(255) NOT NULL,
  subject     VARCHAR(200),
  message     TEXT         NOT NULL,
  created_at  TIMESTAMP    DEFAULT NOW()
);

-- Projects
CREATE TABLE IF NOT EXISTS projects (
  id          SERIAL PRIMARY KEY,
  name        VARCHAR(200) NOT NULL,
  description TEXT,
  tags        JSONB        DEFAULT '[]',
  emoji       VARCHAR(10)  DEFAULT '🚀',
  demo_url    VARCHAR(500),
  code_url    VARCHAR(500),
  featured    BOOLEAN      DEFAULT FALSE,
  created_at  TIMESTAMP    DEFAULT NOW()
);

-- Skills
CREATE TABLE IF NOT EXISTS skills (
  id          SERIAL PRIMARY KEY,
  name        VARCHAR(100) NOT NULL,
  icon        VARCHAR(10),
  category    VARCHAR(50)  NOT NULL,  -- frontend | backend | db | tools
  percentage  INT          DEFAULT 80 CHECK (percentage BETWEEN 0 AND 100),
  sort_order  INT          DEFAULT 0
);

-- ─── Seed: Projects ──────────────────────────────────────
INSERT INTO projects (name, description, tags, emoji, demo_url, code_url, featured) VALUES
('SaaS Dashboard',       'Real-time analytics dashboard built with React, Node.js, WebSockets, and PostgreSQL.',
 '["React","Node.js","Postgres","Redis"]', '🚀', '#', '#', TRUE),
('E-Commerce Platform',  'Full-stack marketplace with Stripe integration and headless CMS.',
 '["Next.js","Django","MySQL","Stripe"]', '🛒', '#', '#', FALSE),
('AI Writing Tool',      'Claude-powered writing assistant with document collaboration and real-time sync.',
 '["React","FastAPI","MongoDB","AI"]',    '🤖', '#', '#', TRUE);

-- ─── Seed: Skills ────────────────────────────────────────
INSERT INTO skills (name, icon, category, percentage, sort_order) VALUES
('React / Next.js',    '⚛',  'frontend', 95, 1),
('TypeScript',         '📘', 'frontend', 90, 2),
('CSS / Tailwind',     '🎨', 'frontend', 88, 3),
('Vue.js',             '💚', 'frontend', 75, 4),
('Node.js / Express',  '🟢', 'backend',  93, 1),
('Python / FastAPI',   '🐍', 'backend',  87, 2),
('GraphQL',            '◈',  'backend',  80, 3),
('REST API Design',    '🔌', 'backend',  95, 4),
('PostgreSQL',         '🐘', 'db',       90, 1),
('MongoDB',            '🍃', 'db',       82, 2),
('Redis',              '🔴', 'db',       78, 3),
('AWS / GCP',          '☁',  'db',       80, 4),
('Docker / Kubernetes','🐳', 'tools',    83, 1),
('Git / CI/CD',        '⎇',  'tools',    92, 2),
('System Design',      '🏗',  'tools',    85, 3),
('Jest / Vitest',      '✅', 'tools',    88, 4);
