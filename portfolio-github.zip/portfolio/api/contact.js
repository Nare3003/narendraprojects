const express = require('express');
const router  = express.Router();
const db      = require('../config/db');

// POST /api/contact
router.post('/', async (req, res) => {
  const { fname, lname, email, subject, message } = req.body;

  if (!fname || !email || !message) {
    return res.status(400).json({ error: 'Name, email, and message are required.' });
  }

  try {
    const result = await db.query(
      `INSERT INTO messages (fname, lname, email, subject, message, created_at)
       VALUES ($1, $2, $3, $4, $5, NOW()) RETURNING id`,
      [fname, lname, email, subject, message]
    );
    res.status(201).json({ success: true, id: result.rows[0].id });
  } catch (err) {
    console.error('DB error:', err.message);
    res.status(500).json({ error: 'Failed to save message.' });
  }
});

// GET /api/contact  (admin — list all messages)
router.get('/', async (req, res) => {
  try {
    const result = await db.query('SELECT * FROM messages ORDER BY created_at DESC');
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
