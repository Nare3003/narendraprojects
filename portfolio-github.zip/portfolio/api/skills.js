const express = require('express');
const router  = express.Router();
const db      = require('../config/db');

// GET /api/skills
router.get('/', async (req, res) => {
  try {
    const result = await db.query('SELECT * FROM skills ORDER BY category, sort_order');
    // Group by category
    const grouped = result.rows.reduce((acc, row) => {
      if (!acc[row.category]) acc[row.category] = [];
      acc[row.category].push(row);
      return acc;
    }, {});
    res.json(grouped);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
