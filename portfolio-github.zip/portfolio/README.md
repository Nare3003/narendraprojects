# 🚀 Personal Portfolio — Full Stack

A production-ready personal portfolio built with **Node.js + Express + PostgreSQL**, deployed easily to Render, Railway, or Vercel.

---

## 📁 Project Structure

```
portfolio/
├── public/
│   └── index.html        # Frontend (HTML + CSS + JS)
├── api/
│   ├── contact.js        # POST /api/contact
│   ├── projects.js       # GET/POST/DELETE /api/projects
│   └── skills.js         # GET /api/skills
├── config/
│   ├── db.js             # PostgreSQL connection
│   └── schema.sql        # Database tables + seed data
├── server.js             # Express entry point
├── package.json
├── .env.example          # Copy to .env
└── .gitignore
```

---

## ⚡ Quick Start (Local)

### 1. Clone the repo
```bash
git clone https://github.com/YOUR_USERNAME/portfolio.git
cd portfolio
```

### 2. Install dependencies
```bash
npm install
```

### 3. Set up environment variables
```bash
cp .env.example .env
# Edit .env and add your PostgreSQL connection string
```

### 4. Create the database and seed it
```bash
psql -U postgres -c "CREATE DATABASE portfolio_db;"
npm run db:setup
```

### 5. Start the server
```bash
npm run dev       # development (auto-reload)
npm start         # production
```

Visit `http://localhost:3000` 🎉

---

## 🌐 Deploy to Render (Free)

1. Push this repo to GitHub
2. Go to [render.com](https://render.com) → **New Web Service**
3. Connect your GitHub repo
4. Set:
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
5. Add a **PostgreSQL** database on Render
6. Copy the **DATABASE_URL** from Render → paste it as an Environment Variable
7. Run the schema: open Render's **Shell** tab and run:
   ```bash
   npm run db:setup
   ```
8. Your portfolio is live! ✅

---

## 🌐 Deploy to Railway

```bash
# Install Railway CLI
npm install -g @railway/cli

railway login
railway init
railway add postgresql
railway up
```

---

## 🔌 API Endpoints

| Method | Route | Description |
|--------|-------|-------------|
| `GET`  | `/api/projects` | List all projects |
| `POST` | `/api/projects` | Add a new project |
| `DELETE` | `/api/projects/:id` | Remove a project |
| `GET`  | `/api/skills` | Get skills grouped by category |
| `POST` | `/api/contact` | Submit contact form |
| `GET`  | `/api/contact` | List all contact messages |

---

## 🛠 Tech Stack

- **Frontend:** HTML5, CSS3, Vanilla JavaScript
- **Backend:** Node.js, Express.js
- **Database:** PostgreSQL (via `pg`)
- **Deploy:** Render / Railway / Heroku

---

## ✏️ Customization

1. Open `public/index.html`
2. Replace `Alex Chen` with your name
3. Update the projects array in the `<script>` block (or fetch from `/api/projects`)
4. Update contact links (email, GitHub, LinkedIn)
5. Update the timeline in the About section

---

## 📄 License

MIT © Alex Chen
