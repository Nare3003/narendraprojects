import { useAuth } from "../context/AuthContext.jsx";
import { useCart } from "../context/CartContext.jsx";

export default function Topbar({ page, setPage }) {
  const { user, logout } = useAuth();
  const { count } = useCart();
  return (
    <nav className="topbar">
      <div className="topbar-brand" onClick={() => setPage("catalog")}>
        Shop<span>Arc</span>
      </div>
      <div className="topbar-nav">
        <button className={`nav-btn ${page === "catalog" ? "active" : ""}`} onClick={() => setPage("catalog")}>
          🏪 Catalog
        </button>
        <button className={`nav-btn ${page === "orders" ? "active" : ""}`} onClick={() => setPage("orders")}>
          📦 Orders
        </button>
        {user?.role === "admin" && (
          <button className={`nav-btn ${page === "admin" ? "active" : ""}`} onClick={() => setPage("admin")}>
            ⚙️ Admin
          </button>
        )}
        <button className="nav-btn" onClick={logout}>
          👤 {user?.name?.split(" ")[0]} · Sign out
        </button>
        <button className="cart-btn" onClick={() => setPage("cart")}>
          🛒 Cart {count > 0 && <span className="badge">{count}</span>}
        </button>
      </div>
    </nav>
  );
}
