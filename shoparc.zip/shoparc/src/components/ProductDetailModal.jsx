import { useState } from "react";
import { useCart } from "../context/CartContext.jsx";
import { fmt } from "../data/seed.js";

export default function ProductDetailModal({ product, onClose }) {
  const { dispatch } = useCart();
  const [added, setAdded] = useState(false);

  const addToCart = () => {
    dispatch({ type: "ADD", product });
    setAdded(true);
    setTimeout(() => setAdded(false), 1800);
  };

  return (
    <div className="modal-backdrop" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal" style={{ maxWidth: 680 }}>
        <div className="modal-header">
          <span className="modal-title">Product Details</span>
          <button className="modal-close" onClick={onClose}>
            ✕
          </button>
        </div>
        <div className="modal-body">
          <div className="detail-grid">
            <div className="detail-img">{product.image}</div>
            <div>
              <div className="detail-cat">{product.category}</div>
              <div className="detail-name">{product.name}</div>
              <div className="product-rating" style={{ marginBottom: 12 }}>
                <span className="stars">
                  {"★".repeat(Math.round(product.rating))}
                  {"☆".repeat(5 - Math.round(product.rating))}
                </span>
                <span>
                  {product.rating} · {product.reviews} reviews
                </span>
              </div>
              <div className="detail-price">{fmt(product.price)}</div>
              <div className="detail-desc">{product.description}</div>
              <div className="detail-meta">
                <div className="detail-meta-item">
                  <div className="detail-meta-val">{product.stock}</div>
                  <div className="detail-meta-label">In stock</div>
                </div>
                <div className="detail-meta-item">
                  <div className="detail-meta-val">{product.rating}★</div>
                  <div className="detail-meta-label">Rating</div>
                </div>
                <div className="detail-meta-item">
                  <div className="detail-meta-val">{product.reviews}</div>
                  <div className="detail-meta-label">Reviews</div>
                </div>
              </div>
              <button className="btn btn-primary btn-lg btn-full" onClick={addToCart} disabled={product.stock === 0}>
                {product.stock === 0 ? "Out of Stock" : added ? "✓ Added to Cart!" : "Add to Cart"}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
