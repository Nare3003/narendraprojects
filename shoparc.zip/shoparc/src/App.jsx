import { useState } from "react";
import { AuthProvider, useAuth } from "./context/AuthContext.jsx";
import { StoreProvider } from "./context/StoreContext.jsx";
import { CartProvider } from "./context/CartContext.jsx";
import Topbar from "./components/Topbar.jsx";
import LoginPage from "./pages/LoginPage.jsx";
import CatalogPage from "./pages/CatalogPage.jsx";
import CartPage from "./pages/CartPage.jsx";
import CheckoutPage from "./pages/CheckoutPage.jsx";
import OrdersPage from "./pages/OrdersPage.jsx";
import AdminPage from "./pages/AdminPage.jsx";

function AppInner() {
  const { user } = useAuth();
  const [page, setPage] = useState("catalog");

  if (!user) return <LoginPage />;

  return (
    <div className="app">
      <Topbar page={page} setPage={setPage} />
      <main className="main">
        {page === "catalog" && <CatalogPage />}
        {page === "cart" && <CartPage setPage={setPage} />}
        {page === "checkout" && <CheckoutPage setPage={setPage} />}
        {page === "orders" && <OrdersPage />}
        {page === "admin" && user.role === "admin" && <AdminPage />}
        {page === "admin" && user.role !== "admin" && (
          <div className="page">
            <div className="empty">
              <div className="empty-icon">🚫</div>
              <h3>Access Denied</h3>
              <p>Admin access only.</p>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <StoreProvider>
        <CartProvider>
          <AppInner />
        </CartProvider>
      </StoreProvider>
    </AuthProvider>
  );
}
