// Seed data simulating a database. Replace with real API calls to your
// MySQL / PostgreSQL / MongoDB backend (see /server for an Express example).

export const INITIAL_PRODUCTS = [
  { id: 1, name: "Wireless Headphones Pro", price: 129.99, category: "Electronics", stock: 42, image: "🎧", description: "Studio-grade audio with 40hr battery life and active noise cancellation.", rating: 4.8, reviews: 312 },
  { id: 2, name: "Leather Wallet Slim", price: 49.99, category: "Accessories", stock: 118, image: "👛", description: "Genuine full-grain leather, RFID-blocking, fits 8 cards.", rating: 4.6, reviews: 88 },
  { id: 3, name: "Mechanical Keyboard TKL", price: 94.99, category: "Electronics", stock: 27, image: "⌨️", description: "Tactile Brown switches, RGB per-key, hot-swappable PCB.", rating: 4.9, reviews: 541 },
  { id: 4, name: "Stainless Tumbler 32oz", price: 34.99, category: "Kitchen", stock: 73, image: "🥤", description: "Triple-wall vacuum insulation, 24hr cold, 12hr hot. Dishwasher safe.", rating: 4.7, reviews: 209 },
  { id: 5, name: "Yoga Mat Premium", price: 62.0, category: "Sports", stock: 55, image: "🧘", description: "6mm natural rubber, non-slip texture, alignment lines, carry strap.", rating: 4.5, reviews: 167 },
  { id: 6, name: "Desk Lamp LED Arc", price: 78.5, category: "Home", stock: 31, image: "💡", description: "Dimmable 5-color temp, USB-C charging port, touch controls, auto-off.", rating: 4.6, reviews: 94 },
  { id: 7, name: "Running Shoes V3", price: 119.0, category: "Sports", stock: 63, image: "👟", description: "Carbon-plate propulsion, breathable mesh upper, 8mm drop.", rating: 4.8, reviews: 428 },
  { id: 8, name: "Smart Watch Series X", price: 249.99, category: "Electronics", stock: 19, image: "⌚", description: "AMOLED display, GPS, sleep & heart tracking, 7-day battery.", rating: 4.7, reviews: 715 },
  { id: 9, name: "Ceramic Pour-Over Set", price: 44.0, category: "Kitchen", stock: 38, image: "☕", description: "Matte glaze ceramic dripper + glass carafe, 600ml capacity.", rating: 4.9, reviews: 143 },
  { id: 10, name: "Backpack Urban 22L", price: 89.0, category: "Accessories", stock: 47, image: "🎒", description: 'Laptop sleeve to 16", hidden pockets, weatherproof 900D nylon.', rating: 4.6, reviews: 256 },
  { id: 11, name: "Bamboo Cutting Board", price: 28.99, category: "Kitchen", stock: 82, image: "🍽️", description: "End-grain bamboo, juice groove, rubber feet, 18×12 inches.", rating: 4.5, reviews: 72 },
  { id: 12, name: "Resistance Band Set", price: 22.0, category: "Sports", stock: 109, image: "🏋️", description: "5 bands 10–50 lbs, latex-free, door anchor + handle kit included.", rating: 4.4, reviews: 198 },
];

export const INITIAL_USERS = [
  { id: 1, name: "Admin User", email: "admin@shop.com", password: "admin123", role: "admin", joined: "2024-01-10" },
  { id: 2, name: "Jane Smith", email: "jane@example.com", password: "user123", role: "user", joined: "2024-03-22" },
  { id: 3, name: "Bob Chen", email: "bob@example.com", password: "user123", role: "user", joined: "2024-05-08" },
];

export const INITIAL_ORDERS = [
  { id: "ORD-1001", userId: 2, items: [{ productId: 1, qty: 1, price: 129.99 }, { productId: 4, qty: 2, price: 34.99 }], total: 199.97, status: "Delivered", date: "2024-11-15", address: "123 Main St, Springfield" },
  { id: "ORD-1002", userId: 3, items: [{ productId: 8, qty: 1, price: 249.99 }], total: 249.99, status: "Shipped", date: "2024-12-01", address: "456 Oak Ave, Shelbyville" },
  { id: "ORD-1003", userId: 2, items: [{ productId: 3, qty: 1, price: 94.99 }, { productId: 6, qty: 1, price: 78.5 }], total: 173.49, status: "Processing", date: "2024-12-10", address: "123 Main St, Springfield" },
];

export const CATEGORIES = ["All", "Electronics", "Accessories", "Kitchen", "Sports", "Home"];
export const STATUS_OPTIONS = ["Processing", "Shipped", "Delivered", "Cancelled"];

export const fmt = (n) => `$${Number(n).toFixed(2)}`;
