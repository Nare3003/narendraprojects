import { useState } from "react";
import { useAuth } from "../context/AuthContext.jsx";

export default function LoginPage() {
  const { login, register } = useAuth();
  const [tab, setTab] = useState("login");
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [error, setError] = useState("");

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const handleSubmit = () => {
    setError("");
    if (tab === "login") {
      const r = login(form.email, form.password);
      if (!r.ok) setError(r.error);
    } else {
      if (!form.name.trim()) return setError("Name is required.");
      if (form.password.length < 6) return setError("Password must be at least 6 characters.");
      const r = register(form.name, form.email, form.password);
      if (!r.ok) setError(r.error);
    }
  };

  return (
    <div className="login-wrap">
      <div className="login-card">
        <div className="login-logo">
          Shop<span>Arc</span>
        </div>
        <div className="login-sub">Your modern marketplace</div>
        <div className="login-tabs">
          <button
            className={`login-tab ${tab === "login" ? "active" : ""}`}
            onClick={() => {
              setTab("login");
              setError("");
            }}
          >
            Sign In
          </button>
          <button
            className={`login-tab ${tab === "register" ? "active" : ""}`}
            onClick={() => {
              setTab("register");
              setError("");
            }}
          >
            Create Account
          </button>
        </div>
        {error && <div className="error-msg">{error}</div>}
        {tab === "register" && (
          <div className="form-group">
            <label className="form-label">Full Name</label>
            <input className="form-control" placeholder="Jane Smith" value={form.name} onChange={(e) => set("name", e.target.value)} />
          </div>
        )}
        <div className="form-group">
          <label className="form-label">Email</label>
          <input className="form-control" type="email" placeholder="you@example.com" value={form.email} onChange={(e) => set("email", e.target.value)} />
        </div>
        <div className="form-group">
          <label className="form-label">Password</label>
          <input
            className="form-control"
            type="password"
            placeholder="••••••••"
            value={form.password}
            onChange={(e) => set("password", e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSubmit()}
          />
        </div>
        <button className="btn btn-primary btn-full btn-lg" onClick={handleSubmit}>
          {tab === "login" ? "Sign In →" : "Create Account →"}
        </button>
        <div className="demo-creds">
          <p>Demo credentials</p>
          <div className="demo-cred">
            Admin: <span>admin@shop.com / admin123</span>
          </div>
          <div className="demo-cred">
            User: <span>jane@example.com / user123</span>
          </div>
        </div>
      </div>
    </div>
  );
}
