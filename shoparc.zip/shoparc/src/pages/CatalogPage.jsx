import { useState } from "react";
import { useStore } from "../context/StoreContext.jsx";
import { useCart } from "../context/CartContext.jsx";
import { CATEGORIES, fmt } from "../data/seed.js";
import ProductDetailModal from "../components/ProductDetailModal.jsx";

export default function CatalogPage() {
  const { products } = useStore();
  const { dispatch } = useCart();
  const [category, setCategory] = useState("All");
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState(null);
  const [justAdded, setJustAdded] = useState({});

  const filtered = products.filter((p) => {
    const matchCat = category === "All" || p.category === category;
    const matchSearch =
      p.name.toLowerCase().includes(search.toLowerCase()) || p.category.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  const quickAdd = (e, product) => {
    e.stopPropagation();
    dispatch({ type: "ADD", product });
    setJustAdded((prev) => ({ ...prev, [product.id]: true }));
    setTimeout(() => setJustAdded((prev) => ({ ...prev, [product.id]: false })), 1500);
  };

  return (
    <div className="page">
      {selected && <ProductDetailModal product={selected} onClose={() => setSelected(null)} />}
      <div className="section-row">
        <div className="section-head" style={{ margin: 0 }}>
          <h1 className="page-title">Catalog</h1>
          <p className="text-muted" style={{ fontSize: 13 }}>
            {filtered.length} products
          </p>
        </div>
        <div className="search-bar">
          <span className="search-icon">🔍</span>
          <input placeholder="Search products…" value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
      </div>
      <div className="filters" style={{ marginBottom: 24 }}>
        {CATEGORIES.map((c) => (
          <button key={c} className={`filter-chip ${category === c ? "active" : ""}`} onClick={() => setCategory(c)}>
            {c}
          </button>
        ))}
      </div>
      {filtered.length === 0 ? (
        <div className="empty">
          <div className="empty-icon">🔍</div>
          <h3>No products found</h3>
          <p>Try adjusting your search or filters.</p>
        </div>
      ) : (
        <div className="product-grid">
          {filtered.map((p) => (
            <div key={p.id} className="product-card" onClick={() => setSelected(p)}>
              <div className="product-img">{p.image}</div>
              <div className="product-body">
                <div className="product-cat">{p.category}</div>
                <div className="product-name">{p.name}</div>
                <div className="product-desc">{p.description}</div>
                <div className="product-rating">
                  <span className="stars">{"★".repeat(Math.round(p.rating))}</span>
                  <span>
                    {p.rating} ({p.reviews})
                  </span>
                </div>
                <div className="product-footer">
                  <div>
                    <div className="product-price">{fmt(p.price)}</div>
                    <div className="stock-badge">{p.stock > 0 ? `${p.stock} left` : "Out of stock"}</div>
                  </div>
                  <button
                    className={`btn btn-sm ${justAdded[p.id] ? "btn-secondary" : "btn-primary"}`}
                    onClick={(e) => quickAdd(e, p)}
                    disabled={p.stock === 0}
                    style={{ fontSize: 11 }}
                  >
                    {justAdded[p.id] ? "✓ Added" : "+ Cart"}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
