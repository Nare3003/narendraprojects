import { useCart } from "../context/CartContext.jsx";
import { fmt } from "../data/seed.js";

export default function CartPage({ setPage }) {
  const { cart, dispatch, total } = useCart();
  const subtotal = total;
  const shipping = subtotal > 75 ? 0 : 9.99;
  const tax = subtotal * 0.08;
  const grand = subtotal + shipping + tax;

  if (cart.length === 0)
    return (
      <div className="page">
        <div className="empty">
          <div className="empty-icon">🛒</div>
          <h3>Your cart is empty</h3>
          <p>Add some products to get started.</p>
          <br />
          <button className="btn btn-primary" onClick={() => setPage("catalog")}>
            Browse Catalog
          </button>
        </div>
      </div>
    );

  return (
    <div className="page">
      <div className="page-title" style={{ marginBottom: 24 }}>
        Shopping Cart
      </div>
      <div className="cart-wrap">
        <div className="card">
          <div className="card-header flex-between">
            <span style={{ fontWeight: 600 }}>
              {cart.length} item{cart.length !== 1 ? "s" : ""}
            </span>
            <button className="btn btn-ghost btn-sm" onClick={() => dispatch({ type: "CLEAR" })}>
              Clear all
            </button>
          </div>
          <div className="card-body" style={{ padding: 0 }}>
            {cart.map((item) => (
              <div key={item.id} className="cart-item">
                <div className="cart-emoji">{item.image}</div>
                <div className="cart-item-info">
                  <div className="cart-item-name">{item.name}</div>
                  <div className="cart-item-price">{fmt(item.price)} each</div>
                </div>
                <div className="qty-ctrl">
                  <button
                    className="qty-btn"
                    onClick={() =>
                      item.qty === 1
                        ? dispatch({ type: "REMOVE", id: item.id })
                        : dispatch({ type: "UPDATE_QTY", id: item.id, qty: item.qty - 1 })
                    }
                  >
                    −
                  </button>
                  <span className="qty-val">{item.qty}</span>
                  <button className="qty-btn" onClick={() => dispatch({ type: "UPDATE_QTY", id: item.id, qty: item.qty + 1 })}>
                    +
                  </button>
                </div>
                <div className="cart-item-total">{fmt(item.price * item.qty)}</div>
                <button className="btn btn-ghost btn-sm" style={{ padding: "6px 8px" }} onClick={() => dispatch({ type: "REMOVE", id: item.id })}>
                  ✕
                </button>
              </div>
            ))}
          </div>
        </div>
        <div>
          <div className="card">
            <div className="card-header">
              <span style={{ fontWeight: 700 }}>Order Summary</span>
            </div>
            <div className="card-body">
              <div className="summary-row">
                <span>Subtotal</span>
                <span>{fmt(subtotal)}</span>
              </div>
              <div className="summary-row">
                <span>
                  Shipping{" "}
                  {subtotal > 75 && (
                    <span className="pill" style={{ background: "var(--accent-light)", color: "var(--accent-dark)" }}>
                      FREE
                    </span>
                  )}
                </span>
                <span>{shipping === 0 ? "Free" : fmt(shipping)}</span>
              </div>
              <div className="summary-row">
                <span>Tax (8%)</span>
                <span>{fmt(tax)}</span>
              </div>
              <hr className="divider" />
              <div className="flex-between">
                <span className="summary-total">Total</span>
                <span className="summary-total">{fmt(grand)}</span>
              </div>
            </div>
            <div className="card-footer">
              <button className="btn btn-primary btn-full btn-lg" onClick={() => setPage("checkout")}>
                Proceed to Checkout →
              </button>
              {subtotal < 75 && <p className="text-sm text-muted mt-4">Add {fmt(75 - subtotal)} more for free shipping!</p>}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
