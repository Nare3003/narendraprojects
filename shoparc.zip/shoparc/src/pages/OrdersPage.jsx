import { useAuth } from "../context/AuthContext.jsx";
import { useStore } from "../context/StoreContext.jsx";
import { fmt } from "../data/seed.js";

export default function OrdersPage() {
  const { user } = useAuth();
  const { orders, products } = useStore();
  const userOrders = orders.filter((o) => o.userId === user.id).sort((a, b) => b.date.localeCompare(a.date));

  if (userOrders.length === 0)
    return (
      <div className="page">
        <div className="empty">
          <div className="empty-icon">📦</div>
          <h3>No orders yet</h3>
          <p>Your orders will appear here after checkout.</p>
        </div>
      </div>
    );

  return (
    <div className="page">
      <div className="page-title" style={{ marginBottom: 24 }}>
        My Orders
      </div>
      {userOrders.map((o) => (
        <div key={o.id} className="order-card">
          <div className="order-header">
            <div>
              <div className="order-id">{o.id}</div>
              <div className="order-date">
                {o.date} · {o.address}
              </div>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <span className={`status-badge status-${o.status}`}>
                <span className="status-dot" />
                {o.status}
              </span>
              <span style={{ fontWeight: 700, fontSize: 15 }}>{fmt(o.total)}</span>
            </div>
          </div>
          <div className="order-items">
            {o.items.map((item, idx) => {
              const p = products.find((x) => x.id === item.productId);
              return (
                <div key={idx} className="order-item-tag">
                  {p?.image} {p?.name || "Product"} × {item.qty}
                </div>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}
