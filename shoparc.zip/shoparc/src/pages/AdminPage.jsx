import { useState } from "react";
import { useAuth } from "../context/AuthContext.jsx";
import { useStore } from "../context/StoreContext.jsx";
import { CATEGORIES, STATUS_OPTIONS, fmt } from "../data/seed.js";

export default function AdminPage() {
  const { users } = useAuth();
  const { products, orders, addProduct, updateProduct, deleteProduct, updateOrderStatus } = useStore();
  const [tab, setTab] = useState("overview");
  const [showAddModal, setShowAddModal] = useState(false);
  const [editProduct, setEditProduct] = useState(null);
  const [newProd, setNewProd] = useState({ name: "", price: "", category: "Electronics", stock: "", image: "📦", description: "" });

  const totalRevenue = orders.filter((o) => o.status !== "Cancelled").reduce((s, o) => s + o.total, 0);
  const setNP = (k, v) => setNewProd((prev) => ({ ...prev, [k]: v }));

  const handleAdd = () => {
    addProduct({ ...newProd, price: parseFloat(newProd.price), stock: parseInt(newProd.stock) });
    setNewProd({ name: "", price: "", category: "Electronics", stock: "", image: "📦", description: "" });
    setShowAddModal(false);
  };

  const handleUpdate = () => {
    updateProduct(editProduct.id, editProduct);
    setEditProduct(null);
  };

  return (
    <div className="page">
      {showAddModal && (
        <div className="modal-backdrop" onClick={(e) => e.target === e.currentTarget && setShowAddModal(false)}>
          <div className="modal">
            <div className="modal-header">
              <span className="modal-title">Add Product</span>
              <button className="modal-close" onClick={() => setShowAddModal(false)}>
                ✕
              </button>
            </div>
            <div className="modal-body">
              <div className="form-group">
                <label className="form-label">Product Name</label>
                <input className="form-control" value={newProd.name} onChange={(e) => setNP("name", e.target.value)} placeholder="e.g. Wireless Mouse" />
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">Price ($)</label>
                  <input className="form-control" type="number" value={newProd.price} onChange={(e) => setNP("price", e.target.value)} placeholder="29.99" />
                </div>
                <div className="form-group">
                  <label className="form-label">Stock</label>
                  <input className="form-control" type="number" value={newProd.stock} onChange={(e) => setNP("stock", e.target.value)} placeholder="50" />
                </div>
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">Category</label>
                  <select className="form-control" value={newProd.category} onChange={(e) => setNP("category", e.target.value)}>
                    {CATEGORIES.filter((c) => c !== "All").map((c) => (
                      <option key={c}>{c}</option>
                    ))}
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Emoji Icon</label>
                  <input className="form-control" value={newProd.image} onChange={(e) => setNP("image", e.target.value)} />
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Description</label>
                <textarea
                  className="form-control"
                  rows={3}
                  value={newProd.description}
                  onChange={(e) => setNP("description", e.target.value)}
                  style={{ resize: "vertical" }}
                />
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-ghost" onClick={() => setShowAddModal(false)}>
                Cancel
              </button>
              <button className="btn btn-primary" onClick={handleAdd} disabled={!newProd.name || !newProd.price || !newProd.stock}>
                Add Product
              </button>
            </div>
          </div>
        </div>
      )}

      {editProduct && (
        <div className="modal-backdrop" onClick={(e) => e.target === e.currentTarget && setEditProduct(null)}>
          <div className="modal">
            <div className="modal-header">
              <span className="modal-title">Edit Product</span>
              <button className="modal-close" onClick={() => setEditProduct(null)}>
                ✕
              </button>
            </div>
            <div className="modal-body">
              <div className="form-group">
                <label className="form-label">Name</label>
                <input className="form-control" value={editProduct.name} onChange={(e) => setEditProduct((p) => ({ ...p, name: e.target.value }))} />
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">Price</label>
                  <input
                    className="form-control"
                    type="number"
                    value={editProduct.price}
                    onChange={(e) => setEditProduct((p) => ({ ...p, price: parseFloat(e.target.value) }))}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Stock</label>
                  <input
                    className="form-control"
                    type="number"
                    value={editProduct.stock}
                    onChange={(e) => setEditProduct((p) => ({ ...p, stock: parseInt(e.target.value) }))}
                  />
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Description</label>
                <textarea
                  className="form-control"
                  rows={3}
                  value={editProduct.description}
                  onChange={(e) => setEditProduct((p) => ({ ...p, description: e.target.value }))}
                  style={{ resize: "vertical" }}
                />
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-ghost" onClick={() => setEditProduct(null)}>
                Cancel
              </button>
              <button className="btn btn-primary" onClick={handleUpdate}>
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="flex-between" style={{ marginBottom: 24 }}>
        <div className="page-title">Admin Dashboard</div>
        <span className="pill pill-admin">Admin Access</span>
      </div>

      <div className="admin-tabs">
        {["overview", "products", "orders", "users"].map((t) => (
          <button key={t} className={`admin-tab ${tab === t ? "active" : ""}`} onClick={() => setTab(t)}>
            {t.charAt(0).toUpperCase() + t.slice(1)}
          </button>
        ))}
      </div>

      {tab === "overview" && (
        <>
          <div className="stats-grid">
            <div className="stat-card">
              <div className="stat-label">Total Revenue</div>
              <div className="stat-value">{fmt(totalRevenue)}</div>
              <div className="stat-sub">from {orders.filter((o) => o.status !== "Cancelled").length} orders</div>
            </div>
            <div className="stat-card">
              <div className="stat-label">Total Orders</div>
              <div className="stat-value">{orders.length}</div>
              <div className="stat-sub">{orders.filter((o) => o.status === "Processing").length} processing</div>
            </div>
            <div className="stat-card">
              <div className="stat-label">Products</div>
              <div className="stat-value">{products.length}</div>
              <div className="stat-sub">{products.filter((p) => p.stock === 0).length} out of stock</div>
            </div>
            <div className="stat-card">
              <div className="stat-label">Customers</div>
              <div className="stat-value">{users.filter((u) => u.role === "user").length}</div>
              <div className="stat-sub">registered users</div>
            </div>
          </div>
          <div className="card">
            <div className="card-header flex-between">
              <span style={{ fontWeight: 700 }}>Recent Orders</span>
            </div>
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Order ID</th>
                    <th>Customer</th>
                    <th>Date</th>
                    <th>Total</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {orders
                    .slice(-5)
                    .reverse()
                    .map((o) => {
                      const customer = users.find((u) => u.id === o.userId);
                      return (
                        <tr key={o.id}>
                          <td>
                            <code>{o.id}</code>
                          </td>
                          <td>{customer?.name || "Unknown"}</td>
                          <td>{o.date}</td>
                          <td style={{ fontWeight: 600 }}>{fmt(o.total)}</td>
                          <td>
                            <span className={`status-badge status-${o.status}`}>
                              <span className="status-dot" />
                              {o.status}
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}

      {tab === "products" && (
        <>
          <div className="flex-between" style={{ marginBottom: 16 }}>
            <span style={{ color: "var(--ink2)", fontSize: 13 }}>{products.length} products</span>
            <button className="btn btn-primary btn-sm" onClick={() => setShowAddModal(true)}>
              + Add Product
            </button>
          </div>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Product</th>
                  <th>Category</th>
                  <th>Price</th>
                  <th>Stock</th>
                  <th>Rating</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {products.map((p) => (
                  <tr key={p.id}>
                    <td>
                      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                        <span style={{ fontSize: 24 }}>{p.image}</span>
                        <span style={{ fontWeight: 500 }}>{p.name}</span>
                      </div>
                    </td>
                    <td>{p.category}</td>
                    <td style={{ fontWeight: 600 }}>{fmt(p.price)}</td>
                    <td>
                      <span style={{ color: p.stock === 0 ? "var(--danger)" : p.stock < 10 ? "var(--warning)" : "inherit", fontWeight: p.stock < 10 ? 600 : 400 }}>
                        {p.stock}
                      </span>
                    </td>
                    <td>⭐ {p.rating}</td>
                    <td>
                      <div style={{ display: "flex", gap: 6 }}>
                        <button className="btn btn-ghost btn-sm" onClick={() => setEditProduct({ ...p })}>
                          Edit
                        </button>
                        <button className="btn btn-danger btn-sm" onClick={() => deleteProduct(p.id)}>
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}

      {tab === "orders" && (
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Order ID</th>
                <th>Customer</th>
                <th>Date</th>
                <th>Items</th>
                <th>Total</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((o) => {
                const customer = users.find((u) => u.id === o.userId);
                return (
                  <tr key={o.id}>
                    <td>
                      <code>{o.id}</code>
                    </td>
                    <td>{customer?.name}</td>
                    <td>{o.date}</td>
                    <td>
                      {o.items.length} item{o.items.length !== 1 ? "s" : ""}
                    </td>
                    <td style={{ fontWeight: 600 }}>{fmt(o.total)}</td>
                    <td>
                      <select
                        className="form-control"
                        style={{ padding: "4px 8px", fontSize: 12, width: "auto" }}
                        value={o.status}
                        onChange={(e) => updateOrderStatus(o.id, e.target.value)}
                      >
                        {STATUS_OPTIONS.map((s) => (
                          <option key={s}>{s}</option>
                        ))}
                      </select>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {tab === "users" && (
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Joined</th>
                <th>Orders</th>
              </tr>
            </thead>
            <tbody>
              {users.map((u) => (
                <tr key={u.id}>
                  <td style={{ fontWeight: 500 }}>{u.name}</td>
                  <td>{u.email}</td>
                  <td>
                    <span className={`pill pill-${u.role}`}>{u.role}</span>
                  </td>
                  <td>{u.joined}</td>
                  <td>{orders.filter((o) => o.userId === u.id).length}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
