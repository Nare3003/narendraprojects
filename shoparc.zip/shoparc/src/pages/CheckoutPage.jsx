import { useState } from "react";
import { useCart } from "../context/CartContext.jsx";
import { useAuth } from "../context/AuthContext.jsx";
import { useStore } from "../context/StoreContext.jsx";
import { fmt } from "../data/seed.js";

export default function CheckoutPage({ setPage }) {
  const { cart, dispatch, total } = useCart();
  const { user } = useAuth();
  const { placeOrder } = useStore();
  const [step, setStep] = useState(1);
  const [completedOrder, setCompletedOrder] = useState(null);
  const [form, setForm] = useState({
    name: user?.name || "",
    email: user?.email || "",
    address: "",
    city: "",
    zip: "",
    card: "",
    expiry: "",
    cvv: "",
  });

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  const shipping = total > 75 ? 0 : 9.99;
  const tax = total * 0.08;
  const grand = total + shipping + tax;

  const placeOrd = () => {
    const items = cart.map((i) => ({ productId: i.id, qty: i.qty, price: i.price }));
    const order = placeOrder(user.id, items, grand, `${form.address}, ${form.city} ${form.zip}`);
    dispatch({ type: "CLEAR" });
    setCompletedOrder(order);
    setStep(3);
  };

  if (cart.length === 0 && !completedOrder)
    return (
      <div className="page">
        <div className="empty">
          <div className="empty-icon">🛒</div>
          <h3>Nothing to check out</h3>
          <button className="btn btn-primary mt-4" onClick={() => setPage("catalog")}>
            Browse Catalog
          </button>
        </div>
      </div>
    );

  if (step === 3 && completedOrder)
    return (
      <div className="page page-sm">
        <div className="success-wrap">
          <div className="success-icon">✅</div>
          <h2>Order Placed!</h2>
          <p>Thank you, {user.name}. Your order is confirmed.</p>
          <p className="success-order-id">{completedOrder.id}</p>
          <p className="text-muted text-sm mt-4">Estimated delivery: 3–5 business days</p>
          <div style={{ display: "flex", gap: 12, justifyContent: "center", marginTop: 28 }}>
            <button className="btn btn-primary" onClick={() => setPage("orders")}>
              Track Order
            </button>
            <button className="btn btn-ghost" onClick={() => setPage("catalog")}>
              Continue Shopping
            </button>
          </div>
        </div>
      </div>
    );

  return (
    <div className="page">
      <div className="page-title" style={{ marginBottom: 24 }}>
        Checkout
      </div>
      <div className="step-indicator">
        {["Shipping", "Payment", "Confirm"].map((s, i) => (
          <div key={s} style={{ display: "flex", alignItems: "center", flex: i < 2 ? 1 : "initial" }}>
            <div className={`step ${step === i + 1 ? "active" : step > i + 1 ? "done" : ""}`}>
              <div className="step-num">{step > i + 1 ? "✓" : i + 1}</div>
              <span>{s}</span>
            </div>
            {i < 2 && <div className="step-line" />}
          </div>
        ))}
      </div>
      <div className="checkout-grid">
        <div>
          {step === 1 && (
            <div className="card">
              <div className="card-header">
                <span style={{ fontWeight: 700 }}>Shipping Address</span>
              </div>
              <div className="card-body">
                <div className="form-row">
                  <div className="form-group">
                    <label className="form-label">Full Name</label>
                    <input className="form-control" value={form.name} onChange={(e) => set("name", e.target.value)} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Email</label>
                    <input className="form-control" type="email" value={form.email} onChange={(e) => set("email", e.target.value)} />
                  </div>
                </div>
                <div className="form-group">
                  <label className="form-label">Street Address</label>
                  <input className="form-control" placeholder="123 Main Street" value={form.address} onChange={(e) => set("address", e.target.value)} />
                </div>
                <div className="form-row">
                  <div className="form-group">
                    <label className="form-label">City</label>
                    <input className="form-control" placeholder="Springfield" value={form.city} onChange={(e) => set("city", e.target.value)} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">ZIP Code</label>
                    <input className="form-control" placeholder="12345" value={form.zip} onChange={(e) => set("zip", e.target.value)} />
                  </div>
                </div>
                <button
                  className="btn btn-primary"
                  disabled={!form.name || !form.address || !form.city || !form.zip}
                  onClick={() => setStep(2)}
                >
                  Continue to Payment →
                </button>
              </div>
            </div>
          )}
          {step === 2 && (
            <div className="card">
              <div className="card-header">
                <span style={{ fontWeight: 700 }}>Payment Details</span>
              </div>
              <div className="card-body">
                <div className="form-group">
                  <label className="form-label">Card Number</label>
                  <input className="form-control" placeholder="4242 4242 4242 4242" value={form.card} onChange={(e) => set("card", e.target.value)} maxLength={19} />
                </div>
                <div className="form-row">
                  <div className="form-group">
                    <label className="form-label">Expiry</label>
                    <input className="form-control" placeholder="MM/YY" value={form.expiry} onChange={(e) => set("expiry", e.target.value)} maxLength={5} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">CVV</label>
                    <input className="form-control" placeholder="123" value={form.cvv} onChange={(e) => set("cvv", e.target.value)} maxLength={3} />
                  </div>
                </div>
                <div className="alert alert-success" style={{ display: "flex", gap: 8, alignItems: "center" }}>
                  🔒 This is a demo. No real payments processed.
                </div>
                <div style={{ display: "flex", gap: 10 }}>
                  <button className="btn btn-ghost" onClick={() => setStep(1)}>
                    ← Back
                  </button>
                  <button className="btn btn-primary" disabled={!form.card || !form.expiry || !form.cvv} onClick={() => setStep(3)}>
                    Review Order →
                  </button>
                </div>
              </div>
            </div>
          )}
          {step === 3 && !completedOrder && (
            <div className="card">
              <div className="card-header">
                <span style={{ fontWeight: 700 }}>Confirm Order</span>
              </div>
              <div className="card-body">
                <p className="text-muted" style={{ marginBottom: 12, fontSize: 13 }}>
                  Ship to:{" "}
                  <strong>
                    {form.address}, {form.city} {form.zip}
                  </strong>
                </p>
                {cart.map((i) => (
                  <div key={i.id} className="flex-between" style={{ padding: "8px 0", borderBottom: "1px solid var(--border)", fontSize: 13 }}>
                    <span>
                      {i.image} {i.name} × {i.qty}
                    </span>
                    <span style={{ fontWeight: 600 }}>{fmt(i.price * i.qty)}</span>
                  </div>
                ))}
                <div style={{ marginTop: 16, display: "flex", gap: 10 }}>
                  <button className="btn btn-ghost" onClick={() => setStep(2)}>
                    ← Back
                  </button>
                  <button className="btn btn-primary btn-lg" onClick={placeOrd}>
                    Place Order {fmt(grand)} →
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
        <div className="card" style={{ alignSelf: "start" }}>
          <div className="card-header">
            <span style={{ fontWeight: 700 }}>Your Cart ({cart.length})</span>
          </div>
          <div className="card-body" style={{ padding: "12px 20px" }}>
            {cart.map((i) => (
              <div key={i.id} className="flex-between" style={{ padding: "6px 0", fontSize: 13, borderBottom: "1px solid var(--border)" }}>
                <span>
                  {i.image} {i.name} ×{i.qty}
                </span>
                <span style={{ fontWeight: 600 }}>{fmt(i.price * i.qty)}</span>
              </div>
            ))}
            <hr className="divider" />
            <div className="summary-row">
              <span>Subtotal</span>
              <span>{fmt(total)}</span>
            </div>
            <div className="summary-row">
              <span>Shipping</span>
              <span>{shipping === 0 ? "Free" : fmt(shipping)}</span>
            </div>
            <div className="summary-row">
              <span>Tax</span>
              <span>{fmt(tax)}</span>
            </div>
            <hr className="divider" />
            <div className="flex-between">
              <strong>Total</strong>
              <strong>{fmt(grand)}</strong>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
