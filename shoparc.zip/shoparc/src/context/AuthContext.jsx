import { createContext, useContext, useState } from "react";
import { INITIAL_USERS } from "../data/seed.js";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [users, setUsers] = useState(INITIAL_USERS);

  const login = (email, password) => {
    const found = users.find((u) => u.email === email && u.password === password);
    if (found) {
      setUser(found);
      return { ok: true };
    }
    return { ok: false, error: "Invalid email or password." };
  };

  const logout = () => setUser(null);

  const register = (name, email, password) => {
    if (users.find((u) => u.email === email)) {
      return { ok: false, error: "Email already registered." };
    }
    const newUser = {
      id: users.length + 1,
      name,
      email,
      password,
      role: "user",
      joined: new Date().toISOString().slice(0, 10),
    };
    setUsers((prev) => [...prev, newUser]);
    setUser(newUser);
    return { ok: true };
  };

  return (
    <AuthContext.Provider value={{ user, users, login, logout, register }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
