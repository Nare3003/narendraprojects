import { createContext, useContext, useState } from "react";
import { INITIAL_PRODUCTS, INITIAL_ORDERS } from "../data/seed.js";

const StoreContext = createContext(null);

export function StoreProvider({ children }) {
  const [products, setProducts] = useState(INITIAL_PRODUCTS);
  const [orders, setOrders] = useState(INITIAL_ORDERS);

  const addProduct = (p) =>
    setProducts((prev) => [...prev, { ...p, id: Date.now(), rating: 0, reviews: 0 }]);

  const updateProduct = (id, updates) =>
    setProducts((prev) => prev.map((p) => (p.id === id ? { ...p, ...updates } : p)));

  const deleteProduct = (id) =>
    setProducts((prev) => prev.filter((p) => p.id !== id));

  const placeOrder = (userId, items, total, address) => {
    const order = {
      id: `ORD-${1004 + orders.length}`,
      userId,
      items,
      total,
      status: "Processing",
      date: new Date().toISOString().slice(0, 10),
      address,
    };
    setOrders((prev) => [...prev, order]);
    setProducts((prev) =>
      prev.map((p) => {
        const item = items.find((i) => i.productId === p.id);
        return item ? { ...p, stock: p.stock - item.qty } : p;
      })
    );
    return order;
  };

  const updateOrderStatus = (id, status) =>
    setOrders((prev) => prev.map((o) => (o.id === id ? { ...o, status } : o)));

  return (
    <StoreContext.Provider
      value={{ products, orders, addProduct, updateProduct, deleteProduct, placeOrder, updateOrderStatus }}
    >
      {children}
    </StoreContext.Provider>
  );
}

export const useStore = () => useContext(StoreContext);
