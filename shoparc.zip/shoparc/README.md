# 🛍️ ShopArc

A full-stack e-commerce web application — product catalog, cart, checkout, order tracking, and a role-based admin dashboard.

![React](https://img.shields.io/badge/React-18-61DAFB?logo=react&logoColor=black)
![Vite](https://img.shields.io/badge/Vite-5-646CFF?logo=vite&logoColor=white)
![License](https://img.shields.io/badge/license-MIT-green)

## Features

- 🏪 **Product catalog** — search, category filters, product detail view
- 🛒 **Cart & checkout** — 3-step checkout flow with shipping, tax, and order confirmation
- 🔐 **Auth & roles** — login/register, Admin vs. User access control
- 📦 **Order tracking** — customers see their order history and live status
- ⚙️ **Admin dashboard** — manage products (CRUD), update order statuses, view all users and revenue stats
- 🗄️ **Pluggable backend** — Express API + MySQL schema included in `/server`, ready to swap for PostgreSQL or MongoDB

## Demo Credentials

The frontend ships with in-memory mock data so you can try it immediately, no backend required.

| Role  | Email             | Password   |
|-------|-------------------|------------|
| Admin | admin@shop.com    | admin123   |
| User  | jane@example.com  | user123    |

## Project Structure

```
shoparc/
├── src/
│   ├── components/      # Reusable UI (Topbar, modals)
│   ├── context/         # Auth, Cart, and Store (products/orders) state
│   ├── data/             # Seed data & shared constants
│   ├── pages/            # Route-level pages (Catalog, Cart, Checkout, Orders, Admin)
│   ├── App.jsx
│   ├── main.jsx
│   └── index.css
├── server/                # Express + MySQL API (optional backend)
│   ├── routes/            # auth, products, orders
│   ├── config/db.js
│   ├── schema.sql
│   └── index.js
├── index.html
├── package.json
└── vite.config.js
```

## Getting Started

### Frontend only (mock data, fastest way to try it)

```bash
npm install
npm run dev
```

Open http://localhost:5173 — the app runs entirely client-side using React Context as an in-memory store.

### Full stack (with Express + MySQL backend)

1. Create the database:
   ```bash
   mysql -u root -p < server/schema.sql
   ```
2. Configure environment variables:
   ```bash
   cd server
   cp .env.example .env
   # edit .env with your DB credentials
   ```
3. Install and run the API:
   ```bash
   npm install
   npm run dev
   ```
   The API runs on `http://localhost:5000` by default.
4. Point the frontend at the API by replacing the mock context calls in `src/context/StoreContext.jsx` and `src/context/AuthContext.jsx` with `fetch` calls to `/api/products`, `/api/orders`, `/api/auth/*`.

> The frontend currently uses React state as a mock database so the UI is fully interactive out of the box. The `/server` folder is a ready-to-wire real backend — connecting them is a matter of swapping the context functions for `fetch`/`axios` calls.

## Tech Stack

- **Frontend:** React 18, Vite, plain CSS (no framework)
- **Backend:** Node.js, Express, MySQL (mysql2), JWT auth, bcrypt password hashing
- **State:** React Context API + `useReducer` for cart logic

## Scripts

| Command           | Description                  |
|-------------------|-------------------------------|
| `npm run dev`     | Start the Vite dev server     |
| `npm run build`   | Build for production          |
| `npm run preview` | Preview the production build  |

## License

MIT — see [LICENSE](LICENSE).
