-- ShopArc database schema (MySQL)
-- Run: mysql -u root -p < server/schema.sql

CREATE DATABASE IF NOT EXISTS shoparc;
USE shoparc;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(160) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('admin', 'user') NOT NULL DEFAULT 'user',
  joined DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(160) NOT NULL,
  price DECIMAL(10, 2) NOT NULL,
  category VARCHAR(60) NOT NULL,
  stock INT NOT NULL DEFAULT 0,
  image VARCHAR(20) DEFAULT '📦',
  description TEXT,
  rating DECIMAL(2, 1) DEFAULT 0,
  reviews INT DEFAULT 0
);

CREATE TABLE IF NOT EXISTS orders (
  id VARCHAR(40) PRIMARY KEY,
  user_id INT NOT NULL,
  total DECIMAL(10, 2) NOT NULL,
  status ENUM('Processing', 'Shipped', 'Delivered', 'Cancelled') NOT NULL DEFAULT 'Processing',
  date DATETIME DEFAULT CURRENT_TIMESTAMP,
  address VARCHAR(255),
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS order_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id VARCHAR(40) NOT NULL,
  product_id INT NOT NULL,
  qty INT NOT NULL,
  price DECIMAL(10, 2) NOT NULL,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id)
);

-- Seed an admin user. Password is "admin123" hashed with bcrypt (cost 10).
-- Generate your own hash before deploying to production.
INSERT INTO users (name, email, password, role) VALUES
  ('Admin User', 'admin@shop.com', '$2a$10$8K1p/a0dURXAm7QiTRqGOOXFsVwHFkBmEtfkqXgqV6dPDvJDJzC1y', 'admin');
