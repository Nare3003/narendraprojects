import { Router } from "express";
import { db } from "../config/db.js";

const router = Router();

// GET /api/products - list all products
router.get("/", async (req, res) => {
  try {
    const [rows] = await db.query("SELECT * FROM products ORDER BY id");
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/products/:id - single product
router.get("/:id", async (req, res) => {
  try {
    const [rows] = await db.query("SELECT * FROM products WHERE id = ?", [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ error: "Product not found" });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/products - create product (admin only — add auth middleware)
router.post("/", async (req, res) => {
  const { name, price, category, stock, image, description } = req.body;
  try {
    const [result] = await db.query(
      "INSERT INTO products (name, price, category, stock, image, description, rating, reviews) VALUES (?, ?, ?, ?, ?, ?, 0, 0)",
      [name, price, category, stock, image, description]
    );
    res.status(201).json({ id: result.insertId, ...req.body });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/products/:id - update product (admin only)
router.put("/:id", async (req, res) => {
  const { name, price, category, stock, image, description } = req.body;
  try {
    await db.query(
      "UPDATE products SET name = ?, price = ?, category = ?, stock = ?, image = ?, description = ? WHERE id = ?",
      [name, price, category, stock, image, description, req.params.id]
    );
    res.json({ id: req.params.id, ...req.body });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/products/:id - delete product (admin only)
router.delete("/:id", async (req, res) => {
  try {
    await db.query("DELETE FROM products WHERE id = ?", [req.params.id]);
    res.status(204).end();
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
