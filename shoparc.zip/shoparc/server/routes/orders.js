import { Router } from "express";
import { db } from "../config/db.js";

const router = Router();

// GET /api/orders?userId=2 - list orders (optionally filtered by user)
router.get("/", async (req, res) => {
  try {
    const { userId } = req.query;
    const sql = userId ? "SELECT * FROM orders WHERE user_id = ? ORDER BY date DESC" : "SELECT * FROM orders ORDER BY date DESC";
    const [rows] = await db.query(sql, userId ? [userId] : []);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/orders - place a new order
router.post("/", async (req, res) => {
  const { userId, items, total, address } = req.body;
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();

    const orderId = `ORD-${Date.now()}`;
    await conn.query(
      "INSERT INTO orders (id, user_id, total, status, date, address) VALUES (?, ?, ?, 'Processing', NOW(), ?)",
      [orderId, userId, total, address]
    );

    for (const item of items) {
      await conn.query("INSERT INTO order_items (order_id, product_id, qty, price) VALUES (?, ?, ?, ?)", [
        orderId,
        item.productId,
        item.qty,
        item.price,
      ]);
      await conn.query("UPDATE products SET stock = stock - ? WHERE id = ?", [item.qty, item.productId]);
    }

    await conn.commit();
    res.status(201).json({ id: orderId, status: "Processing" });
  } catch (err) {
    await conn.rollback();
    res.status(500).json({ error: err.message });
  } finally {
    conn.release();
  }
});

// PATCH /api/orders/:id/status - update order status (admin only)
router.patch("/:id/status", async (req, res) => {
  try {
    await db.query("UPDATE orders SET status = ? WHERE id = ?", [req.body.status, req.params.id]);
    res.json({ id: req.params.id, status: req.body.status });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
