// Minimal Express API server for ShopArc.
// Wire this up to MySQL, PostgreSQL, or MongoDB — see config/db.js for the
// MySQL example. The React frontend currently runs on in-memory mock data
// (src/context/*); point it at these routes to go full-stack.

import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import productRoutes from "./routes/products.js";
import orderRoutes from "./routes/orders.js";
import authRoutes from "./routes/auth.js";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

app.use("/api/auth", authRoutes);
app.use("/api/products", productRoutes);
app.use("/api/orders", orderRoutes);

app.get("/api/health", (req, res) => res.json({ status: "ok" }));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`ShopArc API running on port ${PORT}`));
