// MySQL connection pool. Set credentials in a .env file (see .env.example).
// Swap this module out for a PostgreSQL (pg) or MongoDB (mongoose) client
// if you prefer — the route files only call db.query(...).

import mysql from "mysql2/promise";
import dotenv from "dotenv";

dotenv.config();

export const db = mysql.createPool({
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "shoparc",
  waitForConnections: true,
  connectionLimit: 10,
});
