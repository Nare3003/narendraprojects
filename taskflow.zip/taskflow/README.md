# TaskFlow — Task Management App

A clean, responsive task management web application built with **vanilla HTML, CSS, and JavaScript** — no frameworks or build tools required.

![TaskFlow Screenshot](https://via.placeholder.com/800x450/534AB7/ffffff?text=TaskFlow+%E2%80%94+Task+Management+App)

---

## Features

- **User authentication** — switch between 4 user accounts; session persists on page reload
- **Kanban board** — drag-free column layout for To do / In progress / Done
- **List view** — compact table view with sortable columns
- **Full CRUD** — create, edit, and delete tasks with a clean modal form
- **Task detail panel** — view full description, metadata, progress, and threaded comments
- **Real-time stats** — completion percentage, overdue count, and active task count update instantly
- **Smart filters** — filter by My tasks, High priority, Status, or free-text search
- **LocalStorage persistence** — tasks survive page refreshes without a backend
- **Dark mode** — automatic via `prefers-color-scheme`
- **Responsive** — works on mobile, tablet, and desktop

---

## Project Structure

```
taskflow/
├── index.html        # Entry point
├── css/
│   └── style.css     # All styles (CSS custom properties, responsive layout)
├── js/
│   ├── data.js       # Static data: users, seed tasks, constants
│   └── app.js        # Application logic: state, render, CRUD actions
└── README.md
```

---

## Getting Started

### Option 1 — Open directly in browser

No server needed. Just clone and open:

```bash
git clone https://github.com/YOUR_USERNAME/taskflow.git
cd taskflow
open index.html        # macOS
# or double-click index.html in your file manager
```

### Option 2 — Local dev server (recommended)

Using Python:

```bash
cd taskflow
python3 -m http.server 8000
# Open http://localhost:8000
```

Using Node.js + npx:

```bash
cd taskflow
npx serve .
```

---

## How to Use

1. **Sign in** — pick any user account on the login screen
2. **Create a task** — click "New task" in the top bar, or "+ Add task" at the bottom of any column
3. **View details** — click any task card to open the full detail panel
4. **Edit or delete** — use the Edit button inside the detail panel
5. **Filter** — use the sidebar to filter by owner, priority, or status
6. **Search** — type in the search box to filter by title or description
7. **Switch views** — toggle between Board and List view in the sidebar
8. **Comment** — add comments on any task from the detail panel
9. **Sign out** — click your name at the bottom of the sidebar

---

## Technologies

| Layer      | Technology                          |
|------------|-------------------------------------|
| Markup     | HTML5                               |
| Styles     | CSS3 (custom properties, grid, flexbox, `@media`) |
| Logic      | Vanilla JavaScript (ES6+)           |
| Icons      | [Tabler Icons](https://tabler.io/icons) (webfont via CDN) |
| Persistence| `localStorage` (no backend needed)  |

---

## Customisation

### Add a new user

Open `js/data.js` and add an entry to `USERS`:

```js
{ id: 5, name: "Your Name", role: "Your Role", initials: "YN", color: "#E6F1FB", textColor: "#185FA5" }
```

### Add a new tag/category

1. Add the name to the `<select>` in `buildFormModal()` inside `js/app.js`
2. Add a CSS class in `css/style.css`:

```css
.tag-newcategory { background: #E6F1FB; color: #185FA5; }
```

3. Register it in `TAG_CLASS` in `js/data.js`:

```js
const TAG_CLASS = { ..., NewCategory: "tag-newcategory" };
```

### Connect a real backend

Replace the `saveTasks()` / `localStorage` calls in `js/app.js` with `fetch()` calls to your REST API. The state shape is a plain array of task objects — easy to serialise.

---

## Roadmap / Extension Ideas

- [ ] Drag-and-drop between Kanban columns
- [ ] Real-time sync via WebSockets
- [ ] User avatars / photo upload
- [ ] Sub-tasks and checklists
- [ ] Due-date email reminders
- [ ] Export tasks to CSV
- [ ] REST API backend (Node/Express or Django)

---

## Contributing

Pull requests are welcome. For major changes, please open an issue first to discuss what you'd like to change.

1. Fork the repo
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

---

## License

[MIT](LICENSE)
