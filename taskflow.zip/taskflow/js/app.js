/* ============================================================
   TaskFlow — Application Logic
   ============================================================ */

// ── State ────────────────────────────────────────────────────
let state = {
  loggedIn: false,
  currentUser: null,
  tasks: JSON.parse(localStorage.getItem("taskflow_tasks") || "null") || [...INIT_TASKS],
  view: "board",      // "board" | "list"
  filter: "all",      // "all" | "mine" | "high" | "todo" | "inprogress" | "done"
  search: "",
  showNewTask: false,
  showDetail: false,
  editTask: null,
  detailTask: null,
  newComment: "",
  nextId: 9,
  toast: null,
  _defaultStatus: "todo"
};

// ── Persistence ───────────────────────────────────────────────
function saveTasks() {
  localStorage.setItem("taskflow_tasks", JSON.stringify(state.tasks));
}

// ── Helpers ───────────────────────────────────────────────────
function getUser(id) {
  return USERS.find(u => u.id === id) || USERS[0];
}

function dueLabel(d) {
  if (!d) return null;
  const now = new Date();
  const due = new Date(d);
  const diff = Math.ceil((due - now) / (1000 * 60 * 60 * 24));
  if (diff < 0)  return { text: `${Math.abs(diff)}d overdue`, overdue: true };
  if (diff === 0) return { text: "Due today",     overdue: true };
  if (diff === 1) return { text: "Due tomorrow",  overdue: false };
  return { text: `Due ${due.toLocaleDateString("en-US", { month: "short", day: "numeric" })}`, overdue: false };
}

function getFilteredTasks() {
  let tasks = [...state.tasks];
  const f = state.filter;
  if (f === "mine")       tasks = tasks.filter(t => t.assignee === state.currentUser.id);
  else if (f === "high")  tasks = tasks.filter(t => t.priority === "high");
  else if (f === "todo" || f === "inprogress" || f === "done")
                          tasks = tasks.filter(t => t.status === f);
  if (state.search) {
    const q = state.search.toLowerCase();
    tasks = tasks.filter(t =>
      t.title.toLowerCase().includes(q) || t.desc.toLowerCase().includes(q)
    );
  }
  return tasks;
}

function showToast(msg) {
  state.toast = msg;
  render();
  setTimeout(() => { state.toast = null; render(); }, 2500);
}

// ── Render ────────────────────────────────────────────────────
function render() {
  document.getElementById("root").innerHTML = buildApp();
}

function buildApp() {
  if (!state.loggedIn) return buildLogin();
  return `
    <div class="app">
      ${buildSidebar()}
      ${buildMain()}
    </div>
    ${buildModals()}
    ${state.toast ? `<div class="toast"><i class="ti ti-circle-check" aria-hidden="true"></i>${state.toast}</div>` : ""}
  `;
}

// ── Login ─────────────────────────────────────────────────────
let _selectedLoginUser = 1;

function buildLogin() {
  return `
    <div class="login-screen">
      <div class="login-card">
        <div class="login-logo">
          <i class="ti ti-layout-kanban" aria-hidden="true"></i>
          <span>TaskFlow</span>
        </div>
        <p class="login-sub">Welcome back. Select your account to continue.</p>
        <div class="users-grid">
          ${USERS.map(u => `
            <div class="user-opt${u.id === _selectedLoginUser ? " selected" : ""}"
                 onclick="selectLoginUser(${u.id})">
              <div class="avatar" style="background:${u.color};color:${u.textColor};width:36px;height:36px;font-size:12px">
                ${u.initials}
              </div>
              <div>
                <div class="user-opt-name">${u.name}</div>
                <div class="user-opt-role">${u.role}</div>
              </div>
            </div>
          `).join("")}
        </div>
        <button class="btn btn-primary" style="width:100%;justify-content:center" onclick="doLogin()">
          <i class="ti ti-login" aria-hidden="true"></i> Continue
        </button>
      </div>
    </div>
  `;
}

function selectLoginUser(id) {
  _selectedLoginUser = id;
  render();
}

function doLogin() {
  state.currentUser = USERS.find(u => u.id === _selectedLoginUser) || USERS[0];
  state.loggedIn = true;
  render();
}

function doLogout() {
  state.loggedIn = false;
  state.currentUser = null;
  render();
}

// ── Sidebar ───────────────────────────────────────────────────
function buildSidebar() {
  const u = state.currentUser;
  const counts = {
    all:        state.tasks.length,
    mine:       state.tasks.filter(t => t.assignee === u.id).length,
    high:       state.tasks.filter(t => t.priority === "high").length,
    todo:       state.tasks.filter(t => t.status === "todo").length,
    inprogress: state.tasks.filter(t => t.status === "inprogress").length,
    done:       state.tasks.filter(t => t.status === "done").length,
  };

  function navItem(viewKey, icon, label, countKey) {
    const isFilter = ["mine","high","todo","inprogress","done"].includes(viewKey);
    const active = isFilter ? state.filter === viewKey : state.view === viewKey && state.filter === "all";
    return `
      <button class="nav-item${active ? " active" : ""}"
              onclick="${isFilter ? `setFilter('${viewKey}')` : `setView('${viewKey}')`}">
        <i class="ti ti-${icon}" aria-hidden="true"></i>
        <span>${label}</span>
        <span class="nav-badge">${counts[countKey]}</span>
      </button>
    `;
  }

  return `
    <nav class="sidebar" aria-label="Main navigation">
      <div class="sidebar-logo">
        <i class="ti ti-layout-kanban" aria-hidden="true"></i>
        <span>TaskFlow</span>
      </div>

      <div class="nav-section">
        <div class="nav-label">Views</div>
        ${navItem("board", "layout-columns", "Board", "all")}
        ${navItem("list",  "list",           "List view", "all")}
      </div>

      <div class="nav-section" style="margin-top:0.5rem">
        <div class="nav-label">Filter</div>
        ${navItem("mine",       "user",          "My tasks",     "mine")}
        ${navItem("high",       "alert-circle",  "High priority","high")}
        ${navItem("todo",       "circle",        "To do",        "todo")}
        ${navItem("inprogress", "player-play",   "In progress",  "inprogress")}
        ${navItem("done",       "check",         "Done",         "done")}
      </div>

      <div class="sidebar-footer">
        <div class="user-card" onclick="doLogout()" title="Sign out">
          <div class="avatar" style="background:${u.color};color:${u.textColor}">${u.initials}</div>
          <div>
            <div class="user-name">${u.name}</div>
            <div class="user-role">Click to sign out</div>
          </div>
        </div>
      </div>
    </nav>
  `;
}

// ── Main ──────────────────────────────────────────────────────
function buildMain() {
  const tasks    = getFilteredTasks();
  const total    = state.tasks.length;
  const doneAll  = state.tasks.filter(t => t.status === "done").length;
  const inprogAll= state.tasks.filter(t => t.status === "inprogress").length;
  const overdue  = state.tasks.filter(t => {
    if (!t.due || t.status === "done") return false;
    return dueLabel(t.due)?.overdue;
  }).length;
  const pct = Math.round((doneAll / total) * 100);

  const filterTitles = {
    all: "All tasks", mine: "My tasks", high: "High priority",
    todo: "To do", inprogress: "In progress", done: "Done"
  };

  return `
    <div class="main">
      <header class="topbar">
        <span class="topbar-title">${filterTitles[state.filter]}</span>
        <div class="search-wrap">
          <i class="ti ti-search search-icon" aria-hidden="true"></i>
          <input class="search-input" type="search" placeholder="Search tasks…"
                 aria-label="Search tasks"
                 value="${state.search}"
                 oninput="doSearch(this.value)">
        </div>
        <button class="btn btn-primary" onclick="openNewTask()">
          <i class="ti ti-plus" aria-hidden="true"></i> New task
        </button>
      </header>

      <div class="content">
        <div class="stats-row">
          <div class="stat-card">
            <span class="stat-label">Total tasks</span>
            <span class="stat-value">${total}</span>
            <span class="stat-sub">across all boards</span>
          </div>
          <div class="stat-card">
            <span class="stat-label">Completion</span>
            <span class="stat-value">${pct}%</span>
            <div class="progress-bar" style="margin-top:6px">
              <div class="progress-fill" style="width:${pct}%"></div>
            </div>
          </div>
          <div class="stat-card">
            <span class="stat-label">In progress</span>
            <span class="stat-value">${inprogAll}</span>
            <span class="stat-sub">active tasks</span>
          </div>
          <div class="stat-card">
            <span class="stat-label">Overdue</span>
            <span class="stat-value" style="color:${overdue > 0 ? "#A32D2D" : "var(--color-text-primary)"}">
              ${overdue}
            </span>
            <span class="stat-sub">need attention</span>
          </div>
        </div>

        ${state.view === "board" ? buildBoard(tasks) : buildList(tasks)}
      </div>
    </div>
  `;
}

// ── Board ─────────────────────────────────────────────────────
function buildBoard(tasks) {
  return `
    <div class="board">
      ${STATUS_COLS.map(col =>
        buildColumn(col, tasks.filter(t => t.status === col.key))
      ).join("")}
    </div>
  `;
}

function buildColumn(col, tasks) {
  return `
    <div class="column">
      <div class="col-header">
        <div class="col-dot" style="background:${col.dot}"></div>
        <span class="col-title">${col.label}</span>
        <span class="col-count">${tasks.length}</span>
      </div>
      ${tasks.map(t => buildTaskCard(t)).join("")}
      <button class="add-card-btn" onclick="openNewTask('${col.key}')">
        <i class="ti ti-plus" aria-hidden="true"></i> Add task
      </button>
    </div>
  `;
}

function buildTaskCard(t) {
  const u   = getUser(t.assignee);
  const due = t.due ? dueLabel(t.due) : null;
  return `
    <article class="task-card" onclick="openDetail(${t.id})" tabindex="0"
             onkeydown="if(event.key==='Enter')openDetail(${t.id})"
             aria-label="${t.title}">
      <div><span class="task-tag ${TAG_CLASS[t.tag] || "tag-docs"}">${t.tag}</span></div>
      <div class="task-title">${escHtml(t.title)}</div>
      ${t.desc ? `<div class="task-desc">${escHtml(t.desc.substring(0, 80))}${t.desc.length > 80 ? "…" : ""}</div>` : ""}
      ${t.status === "inprogress" ? `<div class="progress-bar"><div class="progress-fill" style="width:${t.progress}%"></div></div>` : ""}
      <div class="task-meta">
        <div class="priority-dot p-${t.priority}" title="${PRIORITY_LABEL[t.priority]} priority"></div>
        <div class="avatar" style="background:${u.color};color:${u.textColor};width:20px;height:20px;font-size:9px" title="${u.name}">
          ${u.initials}
        </div>
        ${due ? `<span class="task-due${due.overdue ? " overdue" : ""}"><i class="ti ti-calendar" aria-hidden="true"></i>${due.text}</span>` : ""}
      </div>
    </article>
  `;
}

// ── List view ─────────────────────────────────────────────────
function buildList(tasks) {
  return `
    <div class="list-view" role="table" aria-label="Task list">
      <div class="list-header" role="row">
        <span role="columnheader">Task</span>
        <span role="columnheader">Assignee</span>
        <span role="columnheader">Status</span>
        <span role="columnheader">Due</span>
        <span role="columnheader">Priority</span>
      </div>
      ${tasks.length === 0
        ? `<div class="list-empty">No tasks match your filter.</div>`
        : tasks.map(t => buildListRow(t)).join("")}
    </div>
  `;
}

function buildListRow(t) {
  const u   = getUser(t.assignee);
  const due = t.due ? dueLabel(t.due) : null;
  return `
    <div class="list-row" role="row" onclick="openDetail(${t.id})" tabindex="0"
         onkeydown="if(event.key==='Enter')openDetail(${t.id})" aria-label="${t.title}">
      <div class="list-cell" style="flex-direction:column;align-items:flex-start;gap:4px">
        <span style="font-size:13px;font-weight:500">${escHtml(t.title)}</span>
        <span class="task-tag ${TAG_CLASS[t.tag] || "tag-docs"}" style="font-size:10px">${t.tag}</span>
      </div>
      <div class="list-cell" style="gap:6px">
        <div class="avatar" style="background:${u.color};color:${u.textColor};width:22px;height:22px;font-size:9px">${u.initials}</div>
        <span style="font-size:12px;color:var(--color-text-secondary)">${u.name.split(" ")[0]}</span>
      </div>
      <div class="list-cell">
        <span style="font-size:11px;font-weight:500;color:${STATUS_COLOR[t.status]}">${STATUS_LABEL[t.status]}</span>
      </div>
      <div class="list-cell">
        ${due ? `<span style="font-size:11px;color:${due.overdue ? "#A32D2D" : "var(--color-text-secondary)"}">${due.text}</span>` : ""}
      </div>
      <div class="list-cell" style="gap:5px">
        <div class="priority-dot p-${t.priority}"></div>
        <span style="font-size:11px;color:var(--color-text-secondary)">${PRIORITY_LABEL[t.priority]}</span>
      </div>
    </div>
  `;
}

// ── Modals ────────────────────────────────────────────────────
function buildModals() {
  let out = "";
  if (state.showNewTask) out += buildFormModal();
  if (state.showDetail && state.detailTask) out += buildDetailModal();
  return out;
}

function buildFormModal() {
  const t = state.editTask;
  return `
    <div class="modal-overlay" onclick="closeModals()" role="dialog" aria-modal="true"
         aria-label="${t ? "Edit task" : "New task"}">
      <div class="modal" onclick="event.stopPropagation()">
        <div class="modal-header">
          <span class="modal-title">${t ? "Edit task" : "New task"}</span>
          <button class="close-btn" onclick="closeModals()" aria-label="Close"><i class="ti ti-x" aria-hidden="true"></i></button>
        </div>

        <div class="form-group">
          <label class="form-label" for="nt-title">Task title</label>
          <input class="form-input" id="nt-title" placeholder="What needs to be done?" value="${t ? escHtml(t.title) : ""}">
        </div>

        <div class="form-group">
          <label class="form-label" for="nt-desc">Description</label>
          <textarea class="form-input form-textarea" id="nt-desc" rows="3"
                    placeholder="Add more detail…">${t ? escHtml(t.desc) : ""}</textarea>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label class="form-label" for="nt-status">Status</label>
            <select class="form-select" id="nt-status">
              <option value="todo"       ${(!t || t.status === "todo")       ? "selected" : ""}>To do</option>
              <option value="inprogress" ${t && t.status === "inprogress"    ? "selected" : ""}>In progress</option>
              <option value="done"       ${t && t.status === "done"          ? "selected" : ""}>Done</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label" for="nt-priority">Priority</label>
            <select class="form-select" id="nt-priority">
              <option value="high" ${t && t.priority === "high"  ? "selected" : ""}>High</option>
              <option value="med"  ${(!t || t.priority === "med") ? "selected" : ""}>Medium</option>
              <option value="low"  ${t && t.priority === "low"   ? "selected" : ""}>Low</option>
            </select>
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label class="form-label" for="nt-assignee">Assignee</label>
            <select class="form-select" id="nt-assignee">
              ${USERS.map(u => `<option value="${u.id}" ${t && t.assignee === u.id ? "selected" : ""}>${u.name}</option>`).join("")}
            </select>
          </div>
          <div class="form-group">
            <label class="form-label" for="nt-due">Due date</label>
            <input class="form-input" type="date" id="nt-due" value="${t && t.due ? t.due : ""}">
          </div>
        </div>

        <div class="form-group">
          <label class="form-label" for="nt-tag">Category</label>
          <select class="form-select" id="nt-tag">
            ${["Design","Engineering","Bug","Docs","Research"].map(tag =>
              `<option value="${tag}" ${t && t.tag === tag ? "selected" : ""}>${tag}</option>`
            ).join("")}
          </select>
        </div>

        <div class="modal-footer">
          ${t ? `<button class="btn btn-danger" style="margin-right:auto" onclick="deleteTask(${t.id})">
                   <i class="ti ti-trash" aria-hidden="true"></i> Delete
                 </button>` : ""}
          <button class="btn" onclick="closeModals()">Cancel</button>
          <button class="btn btn-primary" onclick="${t ? "saveEdit()" : "saveNew()"}">
            ${t ? "Save changes" : "Create task"}
          </button>
        </div>
      </div>
    </div>
  `;
}

function buildDetailModal() {
  const t   = state.detailTask;
  const u   = getUser(t.assignee);
  const due = t.due ? dueLabel(t.due) : null;

  return `
    <div class="modal-overlay" onclick="closeModals()" role="dialog" aria-modal="true" aria-label="${t.title}">
      <div class="modal" onclick="event.stopPropagation()">
        <div class="modal-header">
          <span class="task-tag ${TAG_CLASS[t.tag] || "tag-docs"}">${t.tag}</span>
          <div class="detail-header-actions">
            <button class="btn" onclick="openEditFromDetail(${t.id})">
              <i class="ti ti-edit" aria-hidden="true"></i> Edit
            </button>
            <button class="close-btn" onclick="closeModals()" aria-label="Close">
              <i class="ti ti-x" aria-hidden="true"></i>
            </button>
          </div>
        </div>

        <h2 class="task-title-lg">${escHtml(t.title)}</h2>
        <p class="task-full-desc">${escHtml(t.desc) || "No description."}</p>

        <div class="detail-row">
          <div class="detail-field">
            <div class="detail-field-label">Assignee</div>
            <div style="display:flex;align-items:center;gap:6px;margin-top:4px">
              <div class="avatar" style="background:${u.color};color:${u.textColor}">${u.initials}</div>
              <span class="detail-field-value">${u.name}</span>
            </div>
          </div>
          <div class="detail-field">
            <div class="detail-field-label">Status</div>
            <div class="detail-field-value" style="color:${STATUS_COLOR[t.status]};margin-top:4px">
              ${STATUS_LABEL[t.status]}
            </div>
          </div>
          <div class="detail-field">
            <div class="detail-field-label">Priority</div>
            <div style="display:flex;align-items:center;gap:6px;margin-top:4px">
              <div class="priority-dot p-${t.priority}"></div>
              <span class="detail-field-value">${PRIORITY_LABEL[t.priority]}</span>
            </div>
          </div>
        </div>

        <div class="detail-row">
          <div class="detail-field">
            <div class="detail-field-label">Due date</div>
            <div class="detail-field-value" style="color:${due && due.overdue ? "#A32D2D" : "var(--color-text-primary)"};margin-top:4px">
              ${due ? due.text : "Not set"}
            </div>
          </div>
          ${t.status === "inprogress" ? `
            <div class="detail-field">
              <div class="detail-field-label">Progress</div>
              <div style="margin-top:4px">
                <div class="progress-bar"><div class="progress-fill" style="width:${t.progress}%"></div></div>
                <span style="font-size:11px;color:var(--color-text-secondary)">${t.progress}% complete</span>
              </div>
            </div>
          ` : ""}
        </div>

        <div class="comment-section">
          <div class="comment-label">
            <i class="ti ti-message-circle" aria-hidden="true"></i>
            Comments (${t.comments.length})
          </div>

          ${t.comments.map(c => {
            const cu = getUser(c.user);
            return `
              <div class="comment-item">
                <div class="avatar" style="background:${cu.color};color:${cu.textColor};width:26px;height:26px;font-size:10px;flex-shrink:0">${cu.initials}</div>
                <div class="comment-body">
                  <div class="comment-author">${cu.name}</div>
                  <div class="comment-text">${escHtml(c.text)}</div>
                </div>
              </div>
            `;
          }).join("")}

          <div class="comment-input-row">
            <input class="form-input" id="new-comment" placeholder="Add a comment…"
                   style="flex:1" value="${escHtml(state.newComment)}"
                   oninput="state.newComment=this.value"
                   onkeydown="if(event.key==='Enter')addComment(${t.id})">
            <button class="btn btn-primary" onclick="addComment(${t.id})">Post</button>
          </div>
        </div>
      </div>
    </div>
  `;
}

// ── Actions ───────────────────────────────────────────────────
function setView(v) { state.view = v; state.filter = "all"; render(); }

function setFilter(f) {
  state.filter = state.filter === f ? "all" : f;
  render();
}

function doSearch(v) { state.search = v; render(); }

function openNewTask(status) {
  state.editTask = null;
  state.showNewTask = true;
  state._defaultStatus = status || "todo";
  render();
}

function openDetail(id) {
  state.detailTask = state.tasks.find(t => t.id === id);
  state.showDetail = true;
  state.newComment = "";
  render();
}

function openEditFromDetail(id) {
  state.editTask = state.tasks.find(t => t.id === id);
  state.showDetail = false;
  state.showNewTask = true;
  render();
}

function closeModals() {
  state.showNewTask = false;
  state.showDetail  = false;
  state.editTask    = null;
  state.detailTask  = null;
  render();
}

function saveNew() {
  const title = document.getElementById("nt-title")?.value.trim();
  if (!title) { alert("Please enter a task title."); return; }

  state.tasks.push({
    id:       state.nextId++,
    title,
    desc:     document.getElementById("nt-desc")?.value || "",
    status:   document.getElementById("nt-status")?.value || state._defaultStatus,
    priority: document.getElementById("nt-priority")?.value || "med",
    assignee: parseInt(document.getElementById("nt-assignee")?.value) || state.currentUser.id,
    due:      document.getElementById("nt-due")?.value || "",
    tag:      document.getElementById("nt-tag")?.value || "Design",
    progress: 0,
    comments: []
  });

  saveTasks();
  closeModals();
  showToast("Task created");
}

function saveEdit() {
  const t = state.editTask;
  if (!t) return;
  const title = document.getElementById("nt-title")?.value.trim();
  if (!title) { alert("Please enter a task title."); return; }

  const idx = state.tasks.findIndex(x => x.id === t.id);
  if (idx >= 0) {
    state.tasks[idx] = {
      ...state.tasks[idx],
      title,
      desc:     document.getElementById("nt-desc")?.value || "",
      status:   document.getElementById("nt-status")?.value,
      priority: document.getElementById("nt-priority")?.value,
      assignee: parseInt(document.getElementById("nt-assignee")?.value),
      due:      document.getElementById("nt-due")?.value,
      tag:      document.getElementById("nt-tag")?.value
    };
  }

  saveTasks();
  closeModals();
  showToast("Changes saved");
}

function deleteTask(id) {
  if (!confirm("Delete this task? This cannot be undone.")) return;
  state.tasks = state.tasks.filter(t => t.id !== id);
  saveTasks();
  closeModals();
  showToast("Task deleted");
}

function addComment(tid) {
  const text = state.newComment.trim();
  if (!text) return;

  const idx = state.tasks.findIndex(t => t.id === tid);
  if (idx >= 0) state.tasks[idx].comments.push({ user: state.currentUser.id, text });

  state.detailTask = state.tasks[idx];
  state.newComment = "";
  saveTasks();
  render();
}

// ── Security helper ───────────────────────────────────────────
function escHtml(str) {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

// ── Init ──────────────────────────────────────────────────────
render();
