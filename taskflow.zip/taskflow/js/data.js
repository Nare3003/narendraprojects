/* ============================================================
   TaskFlow — Data & Constants
   ============================================================ */

const USERS = [
  { id: 1, name: "Alex Chen",    role: "Product Manager", initials: "AC", color: "#EEEDFE", textColor: "#534AB7" },
  { id: 2, name: "Priya Sharma", role: "Lead Engineer",   initials: "PS", color: "#E1F5EE", textColor: "#0F6E56" },
  { id: 3, name: "Jordan Lee",   role: "Designer",        initials: "JL", color: "#FAEEDA", textColor: "#854F0B" },
  { id: 4, name: "Sam Torres",   role: "QA Engineer",     initials: "ST", color: "#FBEAF0", textColor: "#993556" }
];

const INIT_TASKS = [
  {
    id: 1, title: "Redesign onboarding flow",
    desc: "Update the user onboarding to reduce drop-off at step 3. Focus on clarity and progressive disclosure.",
    tag: "Design", priority: "high", status: "todo", assignee: 3,
    due: "2026-06-18", progress: 0,
    comments: [{ user: 1, text: "Wireframes look good, let's move forward." }]
  },
  {
    id: 2, title: "Fix payment gateway timeout",
    desc: "Users are seeing 504 errors during peak hours. Investigate load balancer config and retry logic.",
    tag: "Bug", priority: "high", status: "inprogress", assignee: 2,
    due: "2026-06-14", progress: 60,
    comments: [{ user: 2, text: "Root cause found — retry interval too short." }]
  },
  {
    id: 3, title: "API rate limit documentation",
    desc: "Document the new per-endpoint rate limits for external developers in the API reference.",
    tag: "Docs", priority: "low", status: "todo", assignee: 1,
    due: "2026-06-22", progress: 0, comments: []
  },
  {
    id: 4, title: "Dark mode implementation",
    desc: "Implement system-level dark mode toggle. Use CSS custom properties already defined in design tokens.",
    tag: "Engineering", priority: "med", status: "inprogress", assignee: 2,
    due: "2026-06-17", progress: 45,
    comments: [{ user: 3, text: "Tokens are ready, design approved." }]
  },
  {
    id: 5, title: "User interview synthesis",
    desc: "Compile findings from 12 user interviews into themes and actionable insights for Q3 roadmap.",
    tag: "Research", priority: "med", status: "done", assignee: 1,
    due: "2026-06-10", progress: 100, comments: []
  },
  {
    id: 6, title: "Accessibility audit",
    desc: "Run WCAG 2.1 AA audit on the main dashboard and task board views. File issues for any failures.",
    tag: "Engineering", priority: "med", status: "done", assignee: 4,
    due: "2026-06-11", progress: 100,
    comments: [{ user: 4, text: "17 issues filed, 14 already resolved." }]
  },
  {
    id: 7, title: "Mobile responsive fixes",
    desc: "Fix layout breaks on screens below 375px. Sidebar and card grid need special handling.",
    tag: "Bug", priority: "high", status: "todo", assignee: 4,
    due: "2026-06-16", progress: 0, comments: []
  },
  {
    id: 8, title: "Q3 roadmap presentation",
    desc: "Prepare slides for the all-hands on Friday covering Q3 priorities, resource allocation, and key risks.",
    tag: "Design", priority: "med", status: "inprogress", assignee: 3,
    due: "2026-06-20", progress: 30, comments: []
  }
];

const TAG_CLASS = {
  Design:      "tag-design",
  Engineering: "tag-eng",
  Bug:         "tag-bug",
  Docs:        "tag-docs",
  Research:    "tag-research"
};

const PRIORITY_LABEL = { high: "High", med: "Medium", low: "Low" };

const STATUS_COLS = [
  { key: "todo",       label: "To do",       dot: "#AFA9EC" },
  { key: "inprogress", label: "In progress", dot: "#EF9F27" },
  { key: "done",       label: "Done",        dot: "#5DCAA5" }
];

const STATUS_LABEL  = { todo: "To do", inprogress: "In progress", done: "Done" };
const STATUS_COLOR  = { todo: "#534AB7", inprogress: "#EF9F27", done: "#1D9E75" };
